const ORIGINAL_SHOPS = [
    {
        id: "rest_1", name: "مطاعم السلطان ايوب فرع اسيوط", loc: "أسيوط", map: "https://maps.app.goo.gl/dHPxn5qXgs2sDpE4A", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAExd7kcS9D6JRgbTk2gXbVxDUKRNJdQ2oHC9Q7leTPLSmFVXfXWbF7ci2IVa6QKzo7FaFkUX3TblztFFs8--9s1LlhdI21zosT1-VFYsYpoNeqsXVeVSSr7izv5q0l6VzHmSygl=w408-h306-k-no",
        menu: [
            { i: "وجبة رربع فرخة تيكا", p: "155 EGP" },
            { i: "وجبة نص فرخة", p: "275 EGP" },
            { i: "أرز بسمتي كبير", p: "55 EGP" },
            { i: "سلطة خضراء", p: "30 EGP" },
            { i: "طحينة", p: "25 EGP" }
        ]
    },
    {
        id: "rest_2", name: "مطعم بسمتيو اسيوط", loc: "أسيوط", map: "https://maps.app.goo.gl/43XpT5RVjgk9AxGD9", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAEBOyIm5jONS68Q6fq8v3PvUeQcqzvlrpKAB47OiqNnKHsvdUXKy1k2SCr0OTE1Mh7L-Z5ebrPWlofMitY1ZDA5HBOyAehoyjqS7p_06ACdnZmqzjN5LxGZDXGxYkZfgC74YmyU=w408-h271-k-no",
        menu: [
            { i: "بيف برجر كلاسيك", p: "135 EGP" },
            { i: "تشيكن رانش ساندوتش", p: "120 EGP" },
            { i: "بطاطس جامي", p: "60 EGP" },
            { i: "علبة مخلل", p: "15 EGP" }
        ]
    },
    {
        id: "rest_3", name: "مطعم أسماك الحمد", loc: "أسيوط", map: "https://maps.app.goo.gl/SfUHmbjJCyn7crPn9", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHASq0LbgJdr-yTLjskFVbjTu3pNFWzsAJgYAhSYNzEhPphcztVCMWJsRGBwnfi58onkRI8EKkK1OpIsbH_7v2C4mHPAZIIIbX81BeI6Lff2NsTnS9Wx23tMIwc4u_zAElT_cr8=w408-h306-k-no",
        menu: [
            { i: "مكرونة وايت صوص دجاج", p: "110 EGP" },
            { i: "باستا باللحم المفروم", p: "125 EGP" },
            { i: "بطاطس بالجبنة", p: "55 EGP" }
        ]
    },
    {
        id: "rest_4", name: "Alegria", loc: "أسيوط", map: "https://maps.app.goo.gl/MYJ7Vj19VM33wjeN8", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAErIkzYdWQ2Ai8yZphOzZ9YTHHlX8MFVclOqb-q4SutpoBOGTjA06OO4vbV3GeIA0Xvm-IY4ZFp7f-EQfZ0XB0h3zALGQuZOvX5-O35bscRxJchsbXDl8uuA4o6S0IbrMxTrv8K=w408-h612-k-no",
        menu: [
            { i: "سوبر كرانشي", p: "135 EGP" },
            { i: "هوت دوج مكس", p: "95 EGP" },
            { i: "كانيون برجر", p: "160 EGP" }
        ]
    },
    {
        id: "rest_5", name: "Buffalo burger", loc: "أسيوط", map: "https://maps.app.goo.gl/WLWYVD57XKUcWVDt5", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAGKdC7nfU2xbQGicCPSjyVEPB3-okD8kE9XViqQLpDfLJGuKO9XwisQ0LMZiU12UJj7MH-qvZ_9gXD7s6XK2ir8Kb0TBv87SDhM4jDmmmg156rsMsJeCY7oPOQZUN-0JqcY9ZubSQ=w408-h357-k-no",
        menu: [
            { i: "شوجر بوفالو برجر", p: "165 EGP" },
            { i: "تشيكن دايت", p: "140 EGP" },
            { i: "بطاطس كيرلي", p: "65 EGP" }
        ]
    },
    {
        id: "rest_6", name: "كبابجى سمارة", loc: "أسيوط", map: "https://maps.app.goo.gl/Tg7XC4y6WvjrZsUPA", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAGvgm9WOYKRaJw0VTryDEgF-E65Bs5uIo1_8bItHyAudiaZlEpxv8MI0ymJzRguA2DFfFxCBmwTdyl0iS1N9DZHamzFQ5QX9Dbhejl2qrmFsavy2B3vDHl0gjKRI0wREBdCpB9kGQ=w408-h306-k-no",
        menu: [
            { i: "كيلو كفتة مشوية", p: "620 EGP" },
            { i: "وجبة مكس جريل", p: "350 EGP" },
            { i: "شوربة لسان عصفور", p: "40 EGP" }
        ]
    },
    {
        id: "rest_7", name: "ماكدونالدز", loc: "أسيوط", map: "https://maps.app.goo.gl/7jgy2nZDXZ3j7j6L8", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAGHR1xSb4byQ0-dR6IJ24fM8aWuJNEWxeI1XhnfrHZ_jNQCxpgNGGIn1l22iNOgrMmQU0q_sH2mpzJn92sfSkHLZErj5hyx7xy2Bs4KcWJj4GsSM1yKWlkUu4opYp_3KUcHKAw2IHd8tRDB=w408-h306-k-no",
        menu: [
            { i: "بيتزا سوبر سوبريم وسط", p: "260 EGP" },
            { i: "مارجريتا كبير", p: "210 EGP" },
            { i: "بطاطس ويدجز", p: "75 EGP" }
        ]
    },
    {
        id: "rest_8", name: "مطعم سرايا العرب", loc: "أسيوط", map: "https://maps.app.goo.gl/anYa5ugLYNVdoGYz8", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHUAd006Va5zydFPzU6tA4cNKRADVXbAwR79Lfk2aWxuDVQPGllQv41HBfXepqQzFtWfqNHXKlFPmcNay58Df398vqMK5Ih_zQFY4Q4vZCm9525Gxmr4VgmQFHcrC-H6BWS8LY8AA=w408-h272-k-no",
        menu: [
            { i: "ستيك توب لوين", p: "410 EGP" },
            { i: "سلمون مشوي", p: "520 EGP" },
            { i: "سيزر سلاط بالدجاج", p: "160 EGP" }
        ]
    },
    {
        id: "rest_9", name: "كشرى زمان", loc: "أسيوط", map: "https://maps.app.goo.gl/namsiCxmf44VhMGF8", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHi--dQe59OkxH6ZegdxNLyevg_x0JzsnNQ5tA1K8tbXLyOaYKGHCaBuwXnkQV6u496LrxXerH7b-ITOChTJI5IplkXBzUL0manLRxuJYsqnCWQLezC6URyvIzg9qh4uyaAuRv1=w408-h408-k-no",
        menu: [
            { i: "ساندوتش فول بالزيت", p: "15 EGP" },
            { i: "ساندوتش طعمية محشية", p: "18 EGP" },
            { i: "علبة كشري", p: "65 EGP" }
        ]
    },
    {
        id: "rest_10", name: "كشري الميدان", loc: "أسيوط", map: "https://maps.app.goo.gl/Sqpj7xeGeWEh4VTy6", img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAGYpOKy2TQQ4stVDFCrII8oU_4z_aCOMjR_aWBqJKBgO2JyQWHm1M4mhJADIrDip6FrqFLg2puhMfqWBEKgXcLILvAS0dQFV3Caec9ODO-fBTxviqxWOyjq_e3IFJdpguQb2kE=w408-h310-k-no",
        menu: [
            { i: "كيلو سمك بلطي", p: "195 EGP" },
            { i: "طاجن جمبري", p: "240 EGP" },
            { i: "أرز صيادية", p: "40 EGP" }
        ]
    }
];

const SHOP_CUSTOM_KEY  = "shop_custom";
const SHOP_DELETED_KEY = "shop_deleted";
const SHOP_FAVS_KEY    = "shopFavs";
const SHOP_REVIEWS_KEY = "shopReviews";

let shopFavs      = JSON.parse(localStorage.getItem(SHOP_FAVS_KEY))    || [];
let shopReviews   = JSON.parse(localStorage.getItem(SHOP_REVIEWS_KEY)) || {};
let isShopFavMode = false;
let shopAddImgData = null;

function getCustomShops()    { try { return JSON.parse(localStorage.getItem(SHOP_CUSTOM_KEY))  || []; } catch { return []; } }
function saveCustomShops(l)  { localStorage.setItem(SHOP_CUSTOM_KEY, JSON.stringify(l)); }
function getDeletedShops()   { try { return JSON.parse(localStorage.getItem(SHOP_DELETED_KEY)) || []; } catch { return []; } }

function markShopDeleted(id) {
    const d = getDeletedShops();
    if (!d.includes(id)) { d.push(id); localStorage.setItem(SHOP_DELETED_KEY, JSON.stringify(d)); }
}

function getAllShops() {
    const deleted = getDeletedShops();
    return [
        ...ORIGINAL_SHOPS.filter(s => !deleted.includes(s.id)),
        ...getCustomShops()
    ];
}

function renderShops() {
    const grid = document.getElementById('shopsGrid');
    if (!grid) return;

    let list = getAllShops();
    if (isShopFavMode) list = list.filter(s => shopFavs.includes(s.id));

    if (list.length === 0) {
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:50px;">
            <h3>${isShopFavMode ? 'حقيبة المفضلات فارغة 🛍️' : 'لا توجد محلات بعد'}</h3>
        </div>`;
        return;
    }

    const all = getAllShops();
    grid.innerHTML = list.map(s => {
        const isFav    = shopFavs.includes(s.id);
        const isCustom = String(s.id).startsWith('shop_custom_');
        const idx      = all.findIndex(item => item.id === s.id);
        return `
        <div class="rest-card" style="position:relative;">
            <button class="fav-btn ${isFav ? 'active' : ''}"
                onclick="toggleShopFav('${s.id}', '${s.name.replace(/'/g,"\\'")}')">
                ${isFav ? '❤️' : '🤍'}
            </button>
            ${isCustom ? `
            <button onclick="deleteShop('${s.id}')"
                style="position:absolute;top:10px;left:10px;background:rgba(0,0,0,0.55);color:#fff;
                       border:none;border-radius:50%;width:30px;height:30px;cursor:pointer;font-size:14px;z-index:2;">
                🗑
            </button>` : ''}
            <img src="${s.img}" alt="${s.name}"
                onerror="this.src='https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?w=500'">
            <div class="rest-info">
                <h3>${s.name}</h3>
                ${s.loc ? `<p>📍 ${s.loc}</p>` : ''}
                <div class="btns">
                    <button onclick="openShopMenu(${idx})">🛍️ الأقسام والخدمات</button>
                    <a href="${s.map}" target="_blank">🗺️ الموقع</a>
                </div>
            </div>
        </div>`;
    }).join('');
}

async function toggleShopFav(id, name) {
    const userEmail = localStorage.getItem('user_email');
    if (shopFavs.includes(id)) {
        shopFavs = shopFavs.filter(f => f !== id);
    } else {
        shopFavs.push(id);
        if (userEmail) {
            try {
                await fetch('/api/favorites/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: userEmail, placeName: name })
                });
            } catch (err) { console.error("خطأ في السيرفر:", err); }
        } else {
            alert("سجل دخول عشان المفضلات تتحفظ في حسابك!");
        }
    }
    localStorage.setItem(SHOP_FAVS_KEY, JSON.stringify(shopFavs));
    renderShops();
}

function toggleShopView() {
    isShopFavMode = !isShopFavMode;
    const btn = document.getElementById('shopFavBtn');
    if (btn) {
        btn.innerText = isShopFavMode ? "عرض كل المحلات 🏠" : "عرض المفضلات فقط ❤️";
        btn.classList.toggle('active-mode', isShopFavMode);
    }
    renderShops();
}

function openShopMenu(idx) {
    const all = getAllShops();
    const s   = all[idx];
    if (!s) return;

    const reviews = shopReviews[s.id] || [];
    document.getElementById('modalTitle').innerText = s.name;
    document.getElementById('menuItemsList').innerHTML = `
        <h4>أقسام المتجر:</h4>
        ${s.menu && s.menu.length
            ? s.menu.map(m => `<div class="m-item"><span>${m.i}</span><b>${m.p}</b></div>`).join('')
            : '<p style="color:#999;font-size:13px;">لا توجد أقسام مسجلة</p>'}
        <hr>
        <h4>آراء المتسوقين:</h4>
        <div class="rev-form">
            <select id="starsShop">
                <option value="5">⭐⭐⭐⭐⭐</option>
                <option value="4">⭐⭐⭐⭐</option>
                <option value="3">⭐⭐⭐</option>
                <option value="2">⭐⭐</option>
                <option value="1">⭐</option>
            </select>
            <textarea id="commentShop" placeholder="شاركنا رأيك في تجربة التسوق هنا..."></textarea>
            <button onclick="addShopRev('${s.id}', ${idx})">إرسال التعليق</button>
        </div>
        <div class="rev-list">
            ${reviews.map(v => `<div class="comment"><span>${"⭐".repeat(v.s)}</span><p>${v.t}</p></div>`).join('')}
        </div>
    `;
    document.getElementById('menuModal').style.display = 'flex';
}

function addShopRev(id, idx) {
    const s = document.getElementById('starsShop').value;
    const t = document.getElementById('commentShop').value.trim();
    if (!t) return alert("اكتب تعليقك أولاً!");
    if (!shopReviews[id]) shopReviews[id] = [];
    shopReviews[id].unshift({ s: parseInt(s), t });
    localStorage.setItem(SHOP_REVIEWS_KEY, JSON.stringify(shopReviews));
    openShopMenu(idx);
}

function closeModal() {
    document.getElementById('menuModal').style.display = 'none';
}

function deleteShop(id) {
    if (!confirm("هل تريد حذف هذا المحل؟")) return;
    const isOriginal = ORIGINAL_SHOPS.some(s => s.id === id);
    if (isOriginal) {
        markShopDeleted(id);
    } else {
        saveCustomShops(getCustomShops().filter(s => s.id != id));
    }
    shopFavs = shopFavs.filter(f => f !== id);
    localStorage.setItem(SHOP_FAVS_KEY, JSON.stringify(shopFavs));
    renderShops();
    showShopToast("🗑 تم حذف المحل");
}

function openAddModal() {
    document.getElementById('add-modal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    resetShopForm();
}

function closeAddModal() {
    document.getElementById('add-modal').style.display = 'none';
    document.body.style.overflow = '';
}

function resetShopForm() {
    ['add-name', 'add-img-url', 'add-loc'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    const menuList = document.getElementById('add-menu-list');
    if (menuList) menuList.innerHTML = '';
    const preview = document.getElementById('add-img-preview');
    if (preview) preview.innerHTML = 'معاينة الصورة';
    const fileInput = document.getElementById('add-img-file');
    if (fileInput) { fileInput.value = ''; delete fileInput.dataset.base64; }
    shopAddImgData = null;
}

function previewAddImg() {
    const url     = document.getElementById('add-img-url')?.value.trim();
    const preview = document.getElementById('add-img-preview');
    shopAddImgData = null;
    if (preview) preview.innerHTML = url
        ? `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;"
              onerror="this.parentElement.innerHTML='<span style=color:#e74c3c>رابط غلط</span>'" />`
        : 'معاينة الصورة';
}

function handleAddFile() {
    const fileEl = document.getElementById('add-img-file');
    if (!fileEl?.files[0]) return;
    const reader = new FileReader();
    reader.onload = e => {
        shopAddImgData = e.target.result;
        fileEl.dataset.base64 = e.target.result;
        const preview = document.getElementById('add-img-preview');
        if (preview) preview.innerHTML =
            `<img src="${shopAddImgData}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;" />`;
        const urlEl = document.getElementById('add-img-url');
        if (urlEl) urlEl.value = '';
    };
    reader.readAsDataURL(fileEl.files[0]);
}

function addNewProduct() {
    const list = document.getElementById('add-menu-list');
    if (!list) return;
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;align-items:center;';
    row.innerHTML = `
        <input type="text" placeholder="اسم الوجبة أو القسم"
            style="flex:1;padding:9px 12px;border:1px solid #ddd;border-radius:10px;font-size:13px;font-family:inherit;" />
        <input type="text" placeholder="السعر (مثال: 120 EGP)"
            style="width:140px;padding:9px 12px;border:1px solid #ddd;border-radius:10px;font-size:13px;font-family:inherit;" />
        <button onclick="this.parentElement.remove()"
            style="background:#fee;border:none;border-radius:8px;padding:8px 12px;cursor:pointer;color:#c00;font-size:16px;">✕</button>
    `;
    list.appendChild(row);
}

function saveNewShop() {
    const name   = document.getElementById('add-name')?.value.trim();
    const loc    = document.getElementById('add-loc')?.value.trim();
    const fileEl = document.getElementById('add-img-file');
    const urlEl  = document.getElementById('add-img-url');
    const img    = fileEl?.dataset.base64 || urlEl?.value.trim()
                 || 'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?w=500';

    if (!name) {
        alert('⚠️ اكتب اسم المطعم أولاً');
        document.getElementById('add-name')?.focus();
        return;
    }

    const menuRows = document.querySelectorAll('#add-menu-list > div');
    const menu = Array.from(menuRows).map(row => {
        const inputs = row.querySelectorAll('input');
        const itemName = inputs[0]?.value.trim();
        const price    = inputs[1]?.value.trim() || 'متنوعة';
        return itemName ? { i: itemName, p: price } : null;
    }).filter(Boolean);

    const newShop = {
        id: 'shop_custom_' + Date.now(),
        name,
        loc: loc || 'أسيوط',
        img,
        map: loc.startsWith('http') ? loc : `https://maps.app.goo.gl/43XpT5RVjgk9AxGD95{encodeURIComponent(name + " Assiut")}`,
        menu,
        addedAt: new Date().toLocaleDateString('ar-EG')
    };

    const customs = getCustomShops();
    customs.push(newShop);
    saveCustomShops(customs);

    closeAddModal();
    renderShops();
    showShopToast(`✅ تم حفظ "${name}" بنجاح!`);
}

function showShopToast(msg) {
    const toast = document.createElement('div');
    toast.textContent = msg;
    toast.style.cssText = `
        position:fixed;bottom:80px;left:50%;transform:translateX(-50%);
        background:#222;color:#fff;padding:12px 24px;border-radius:50px;
        font-size:14px;z-index:9999;opacity:0;transition:opacity .3s;
        font-family:inherit;white-space:nowrap;pointer-events:none;
    `;
    document.body.appendChild(toast);
    setTimeout(() => (toast.style.opacity = '1'), 10);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 400); }, 3000);
}

document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('add-modal');
    if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeAddModal(); });
    renderShops();
});

window.addEventListener('load', renderShops);