// 1. كود تحديث اسم المستخدم في كل الصفحات
document.addEventListener('DOMContentLoaded', () => {
    const savedName = localStorage.getItem('user_name');
    const openSignupBtn = document.getElementById('openSignup');
    
    if (savedName && openSignupBtn) {
        openSignupBtn.innerText = "أهلاً يا " + savedName;
    }
});

// 2. فانكشن الإضافة للمفضلة الموحدة
async function toggleFav(id, name) {
    let favs = JSON.parse(localStorage.getItem('favs')) || [];
    const userEmail = localStorage.getItem('user_email');

    if (favs.includes(id)) {
        favs = favs.filter(i => i !== id);
    } else {
        favs.push(id);
        if (userEmail) {
            try {
                await fetch('/api/favorites/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: userEmail, placeName: name })
                });
            } catch (err) {
                console.error("خطأ في الاتصال بالسيرفر:", err);
            }
        } else {
            alert("سجل دخول عشان خياراتك تتحفظ في حسابك !");
            return; // وقف الفانكشن هنا عشان ميكملش حفظ في المتصفح لو مش مسجل
        }
    }

    localStorage.setItem('favs', JSON.stringify(favs));
    
    // لو إحنا في صفحة فيها فانكشن render (زي المطاعم) شغلها عشان نحدث الشكل
    if (typeof render === "function") {
        render();
    }
}