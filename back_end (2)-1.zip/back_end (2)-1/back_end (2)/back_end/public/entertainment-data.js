/// ============================================================
//  🎬 مدير الترفيه — entertainment-manager-final.js
//  يجمع الأماكن الأصلية + المضافة من localStorage
// ============================================================

// ─── الأماكن الأصلية الثابتة ───
const ORIGINAL_DATA = [
    {
        id: "ent_1",
        name: "سينما المركز التجاري الدولي",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAFVUOUHcpWpTT0gOd3tOdDUXl1DQ1LlrpuO5BusvhrtCTW7t8NzPaeHDcaN6md85QZmIO6A2fsbILUU9LUxjU2dDzVLx0nGcNDR7_FX8ZDPFmI3j6OKjLQct_u-jrYZ37tOptLf=w408-h307-k-no",
        map: "https://maps.app.goo.gl/A2aA8V1XgD8dQJ9W7",
        menu: [
            { i: "سينما", p: 80 },
            { i: "منطقة مطاعم", p: 100 }
        ]
    },
    {
        id: "ent_2",
        name: "سينما صيدناوى مول",
        img: "https://lh5.googleusercontent.com/6yesDhBAGtxa_AXRH4plTJfdhhZ43AV0R58DrH9oRDi3F4tDwxWiH0MXzXplYC-N=w203-h152-k-no",
        map: "https://maps.app.goo.gl/g4Xpc62Kn5iCSjkHA",
        menu: [
            { i: "تذكرة فيلم", p: 120 }
        ]
    },
    {
        id: "ent_3",
        name: "فوفوزيلا بارك",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHJ15Ex8VRYTGmFIFxnqjuQndAONyjG7rFmFhqJraTTTpYjZARDLOCwJkErzL3dPuVwH28lvPoaRSCMbCGRrxXnvJTVlpK7_CMiK560i9MbEHX_N1Uo6AKgxHEEJ9qsPNZtEOg=w408-h306-k-no",
        map: "https://maps.app.goo.gl/RiRuMZ12pv1iax7v8",
        menu: [
            { i: "ملابس", p: 200 },
            { i: "لعبة بولينج", p: 75 },
            { i: "ألعاب إلكترونية", p: 50 }
        ]
    },
    {
        id: "ent_4",
        name: "Max Park",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAFGlLMzf3c8ogLoFjyL88Bb6ts8yTWJWtYDvZyIEjMUIsJ_ue5goN938dbED4SX99TuG77odccY7wsqli0SuhU9uFR06fWJ8s05CrtTJfFMqkjAAGo5l09V4Gc6iNUrSozgYUYPziAqEUVW=w203-h252-k-no",
        map: "https://maps.app.goo.gl/osAXia2A2K3EYUjy7",
        menu: [
            { i: "ملابس", p: 200 },
            { i: "لعبة بولينج", p: 75 },
            { i: "ألعاب إلكترونية", p: 50 }
        ]
    },
    {
        id: "ent_5",
        name: "X.play park",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAH39iXtpOcO2IBl936ymyYhmDd_CJilWWnUEyMAknKJkPDRrlzUnQebRTkvWx3EWo-ibEGOXRg1FA_cswaQe7cuNBjwuKg5KVeUOHGPYicgrTjxUzZItZ-QyvD4Ydvfz2RxjKA=w519-h240-k-no",
        map: "https://maps.app.goo.gl/rJBgnS4hQdCWVdDE6",
        menu: [
            { i: "ألعاب إلكترونية", p: 50 }
        ]
    }
];

// ─── مفاتيح localStorage ───
const ENT_CUSTOM_KEY  = "ent_custom";    // الأماكن المضافة
const ENT_DELETED_KEY = "ent_deleted";   // IDs الأصليين المحذوفين
const ENT_FAVS_KEY    = "ent_favs";
const ENT_REVIEWS_KEY = "ent_reviews";

// ─── الحالة العامة ───
let entFavs     = JSON.parse(localStorage.getItem(ENT_FAVS_KEY))    || [];
let entReviews  = JSON.parse(localStorage.getItem(ENT_REVIEWS_KEY)) || {};
let showFavsOnly = false;
let entAddImgData = null;

// ============================================================
//  دوال Storage
// ============================================================

function getCustomEnt()   { try { return JSON.parse(localStorage.getItem(ENT_CUSTOM_KEY))  || []; } catch { return []; } }
function saveCustomEnt(l) { localStorage.setItem(ENT_CUSTOM_KEY, JSON.stringify(l)); }
function getDeletedEnt()  { try { return JSON.parse(localStorage.getItem(ENT_DELETED_KEY)) || []; } catch { return []; } }

function markEntDeleted(id) {
    const d = getDeletedEnt();
    if (!d.includes(id)) { d.push(id); localStorage.setItem(ENT_DELETED_KEY, JSON.stringify(d)); }
}

/** كل الأماكن = الأصليين (غير المحذوفين) + المضافين */
function getAllEnt() {
    const deleted = getDeletedEnt();
    return [
        ...ORIGINAL_DATA.filter(p => !deleted.includes(p.id)),
        ...getCustomEnt()
    ];
}

// ============================================================
//  عرض الأماكن
// ============================================================

function render() {
    const grid = document.getElementById('mainGrid');
    if (!grid) return;

    let list = getAllEnt();
    if (showFavsOnly) list = list.filter(x => entFavs.includes(x.id));

    if (list.length === 0) {
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:50px;">
            <h3>${showFavsOnly ? 'المفضلة فارغة ❤️' : 'لا توجد أماكن بعد'}</h3>
        </div>`;
        return;
    }

    grid.innerHTML = list.map(item => {
        const isFav     = entFavs.includes(item.id);
        const isCustom  = String(item.id).startsWith('ent_custom_');
        return `
        <div class="rest-card">
            <button class="fav-btn ${isFav ? 'active' : ''}"
                onclick="toggleFav('${item.id}', '${item.name.replace(/'/g,"\\'")}')">
                ${isFav ? '❤️' : '🤍'}
            </button>
            ${isCustom ? `
            <button onclick="deleteEnt('${item.id}')"
                style="position:absolute;top:10px;left:10px;background:rgba(0,0,0,0.55);color:#fff;
                       border:none;border-radius:50%;width:30px;height:30px;cursor:pointer;font-size:14px;z-index:2;">
                🗑
            </button>` : ''}
            <img src="${item.img}" alt="${item.name}"
                onerror="this.src='https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=500'">
            <div class="rest-info">
                <h3>${item.name}</h3>
                ${item.loc ? `<p>📍 ${item.loc}</p>` : ''}
                <div class="btns">
                    <button onclick="openModal('${item.id}')">📖 التفاصيل</button>
                    <a href="${item.map}" target="_blank">🗺️ الخريطة</a>
                </div>
            </div>
        </div>`;
    }).join('');
}

// ============================================================
//  المفضلة
// ============================================================

async function toggleFav(id, name) {
    const userEmail = localStorage.getItem('user_email');

    if (entFavs.includes(id)) {
        entFavs = entFavs.filter(f => f !== id);
    } else {
        entFavs.push(id);
        if (userEmail) {
            try {
                await fetch('/api/favorites/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: userEmail, placeName: name })
                });
            } catch (err) { console.error("خطأ في السيرفر:", err); }
        } else {
            alert("سجل دخول عشان المفضلات تتحفظ في حسابك!");
        }
    }

    localStorage.setItem(ENT_FAVS_KEY, JSON.stringify(entFavs));
    render();
}

function toggleView() {
    showFavsOnly = !showFavsOnly;
    const btn = document.getElementById('favToggleBtn');
    if (btn) btn.innerText = showFavsOnly ? "عرض الكل" : "عرض المفضلات فقط ❤️";
    render();
}

// ============================================================
//  Modal التفاصيل والتقييمات
// ============================================================

function openModal(id) {
    const item = getAllEnt().find(x => x.id == id);
    if (!item) return;

    const reviews = entReviews[id] || [];
    document.getElementById('modalTitle').innerText = item.name;
    document.getElementById('menuItemsList').innerHTML = `
        <h4>الأسعار والخدمات:</h4>
        ${item.menu && item.menu.length
            ? item.menu.map(m => `<div class="m-item"><span>${m.i}</span><b>${m.p} ج.م</b></div>`).join('')
            : '<p style="color:#999;font-size:13px;">لا توجد تفاصيل أسعار</p>'}
        <hr>
        <div class="rev-form">
            <textarea id="commentInput" placeholder="اكتب رأيك هنا..."></textarea>
            <button onclick="saveReview('${id}')">نشر</button>
        </div>
        <div class="comments-list">
            ${reviews.map(r => `<div class="comment"><p>${r}</p></div>`).join('')}
        </div>
    `;
    document.getElementById('menuModal').style.display = 'flex';
}

function saveReview(id) {
    const txt = document.getElementById('commentInput').value.trim();
    if (!txt) return;
    if (!entReviews[id]) entReviews[id] = [];
    entReviews[id].unshift(txt);
    localStorage.setItem(ENT_REVIEWS_KEY, JSON.stringify(entReviews));
    openModal(id);
}

function closeModal() {
    document.getElementById('menuModal').style.display = 'none';
}

// ============================================================
//  حذف مكان
// ============================================================

function deleteEnt(id) {
    if (!confirm("هل تريد حذف هذا المكان؟")) return;

    const isOriginal = ORIGINAL_DATA.some(p => p.id === id);
    if (isOriginal) {
        markEntDeleted(id);
    } else {
        saveCustomEnt(getCustomEnt().filter(p => p.id != id));
    }

    entFavs = entFavs.filter(f => f !== id);
    localStorage.setItem(ENT_FAVS_KEY, JSON.stringify(entFavs));

    render();
    showToast("🗑 تم حذف المكان");
}

// ============================================================
//  إضافة مكان جديد
// ============================================================

function openAddModal() {
    document.getElementById('add-modal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    resetEntForm();
}

function closeAddModal() {
    document.getElementById('add-modal').style.display = 'none';
    document.body.style.overflow = '';
}

function resetEntForm() {
    ['add-name', 'add-img-url', 'add-loc'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    const menuList = document.getElementById('add-menu-list');
    if (menuList) menuList.innerHTML = '';
    const preview = document.getElementById('add-img-preview');
    if (preview) preview.innerHTML = 'معاينة الصورة';
    const fileInput = document.getElementById('add-img-file');
    if (fileInput) { fileInput.value = ''; delete fileInput.dataset.base64; }
    entAddImgData = null;
}

function previewAddImg() {
    const url = document.getElementById('add-img-url')?.value.trim();
    const preview = document.getElementById('add-img-preview');
    entAddImgData = null;
    if (preview) preview.innerHTML = url
        ? `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;"
              onerror="this.parentElement.innerHTML='<span style=color:#e74c3c>رابط غلط</span>'" />`
        : 'معاينة الصورة';
}

function handleAddFile() {
    const fileEl = document.getElementById('add-img-file');
    if (!fileEl?.files[0]) return;
    const reader = new FileReader();
    reader.onload = e => {
        entAddImgData = e.target.result;
        fileEl.dataset.base64 = e.target.result;
        const preview = document.getElementById('add-img-preview');
        if (preview) preview.innerHTML =
            `<img src="${entAddImgData}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;" />`;
        const urlEl = document.getElementById('add-img-url');
        if (urlEl) urlEl.value = '';
    };
    reader.readAsDataURL(fileEl.files[0]);
}

function addNewDish() {
    const list = document.getElementById('add-menu-list');
    if (!list) return;
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;align-items:center;';
    row.innerHTML = `
        <input type="text" placeholder="اسم الخدمة أو النشاط"
            style="flex:1;padding:9px 12px;border:1px solid #ddd;border-radius:10px;font-size:13px;font-family:inherit;" />
        <input type="number" placeholder="السعر" min="0"
            style="width:90px;padding:9px 12px;border:1px solid #ddd;border-radius:10px;font-size:13px;font-family:inherit;" />
        <button onclick="this.parentElement.remove()"
            style="background:#fee;border:none;border-radius:8px;padding:8px 12px;cursor:pointer;color:#c00;font-size:16px;">✕</button>
    `;
    list.appendChild(row);
}

function saveNewRestaurant() {
    const name   = document.getElementById('add-name')?.value.trim();
    const loc    = document.getElementById('add-loc')?.value.trim();
    const fileEl = document.getElementById('add-img-file');
    const urlEl  = document.getElementById('add-img-url');
    const img    = fileEl?.dataset.base64 || urlEl?.value.trim()
                || 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=500';

    if (!name) {
        alert('⚠️ اكتب اسم المكان');
        document.getElementById('add-name')?.focus();
        return;
    }

    const menuRows = document.querySelectorAll('#add-menu-list > div');
    const menu = Array.from(menuRows).map(row => {
        const inputs = row.querySelectorAll('input');
        const itemName = inputs[0]?.value.trim();
        const price    = parseFloat(inputs[1]?.value) || 0;
        return itemName ? { i: itemName, p: price } : null;
    }).filter(Boolean);

    const newItem = {
        id: 'ent_custom_' + Date.now(),
        name,
        loc: loc || '',
        img,
        map: loc || `https://www.google.com/maps/search/${encodeURIComponent(name + " Assiut")}`,
        menu,
        addedAt: new Date().toLocaleDateString('ar-EG')
    };

    const customs = getCustomEnt();
    customs.push(newItem);
    saveCustomEnt(customs);

    closeAddModal();
    render();
    showToast(`✅ تم حفظ "${name}" بنجاح!`);
}

// ============================================================
//  Toast إشعار
// ============================================================

function showToast(msg) {
    const toast = document.createElement('div');
    toast.textContent = msg;
    toast.style.cssText = `
        position:fixed;bottom:80px;left:50%;transform:translateX(-50%);
        background:#222;color:#fff;padding:12px 24px;border-radius:50px;
        font-size:14px;z-index:9999;opacity:0;transition:opacity .3s;
        font-family:inherit;white-space:nowrap;pointer-events:none;
    `;
    document.body.appendChild(toast);
    setTimeout(() => (toast.style.opacity = '1'), 10);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 400); }, 3000);
}

// ─── aliases تتوافق مع أسماء الدوال في الـ HTML ───
function addNewActivity()            { addNewDish(); }
function saveNewEntertainmentPlace() { saveNewRestaurant(); }

// ============================================================
//  التهيئة
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('add-modal');
    if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeAddModal(); });
    render();
});

window.addEventListener('load', render);