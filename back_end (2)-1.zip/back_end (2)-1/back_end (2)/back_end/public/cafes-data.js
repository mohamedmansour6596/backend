// ==========================
// بيانات الكافيهات
// ==========================
const baseCafes = [
    {
        id: "cafe_1",
        name: "كافيتريا جروبي",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAFzSn39D5c36Gip5CkGCeLhrVuyYiPt4wZFpOh60TP-N06d5hQUTOTdl2c1eLig3JYtiJCC0xReRVVUHwUSrhi2V5oj8uzjBcci23uaMZD8JRMyYDagoaO6ZwYqwjXANE6WtmPBJA=w408-h306-k-no",
        map: "https://maps.app.goo.gl/crpUdftL9WYNHtUq6",
        menu: [
            { i: "شاورما", p: 65 },
            { i: "كريب", p: 55 },
            { i: "برجر", p: 80 }
        ]
    },
    {
        id: "cafe_2",
        name: "Baba Caffee",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAEYs7hz57e_-RR23PLHxIY0oENcP2ulPeer-JDreznxhppqBuKvCTJTgLRrw1WRTdrIhy08AxJn44yBoHaOnWE_JCFn2HCEx5pD1RwFFn27Ln6YRzsmlYxZEKlKpga0Xgs22ho5QA=w485-h240-k-no",
        map: "https://maps.app.goo.gl/baPZobKS8QdLdNLv7",
        menu: [
            { i: "باستا كريمي", p: 110 },
            { i: "ستيك", p: 280 },
            { i: "تشيز كيك", p: 75 }
        ]
    },
    {
        id: "cafe_3",
        name: "Heaven",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHpBR2PZMkIO39ASE3g8lFuSggmv1wyrTYMDLM4zvcZO6SX-epnH3MhGuBYRzfVe3skNm7fq23Ifl56-jk7SorsyB14ZQiUBVCr1XhzO_us9-PQACZdcSKXkl6jczVlaZDOLnwb=w408-h306-k-no",
        map: "https://maps.app.goo.gl/JYUa8vzqbcvgLuWXA",
        menu: [
            { i: "بلطي مشوي", p: 160 },
            { i: "جمبري", p: 220 },
            { i: "سمك مقلي", p: 140 }
        ]
    },
    {
        id: "cafe_4",
        name: "كافيه كوكاتو",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAF_Pwj0ZifzgUx-RCJtPRCmPZ9YJzl3Bhw877jhovbQkbinUFOGGi2bWzAMlclEIGVhQ3kVfSSXySIl4YfMVGvOFnIBeX47ep4_cCBfST7IsQtGzFcV6mpB6uy44hs6cn9Qalw=w408-h544-k-no",
        map: "https://maps.app.goo.gl/rUbAdhrWkoPUuGZt9",
        menu: [
            { i: "لاتيه", p: 65 },
            { i: "كابتشينو", p: 70 },
            { i: "براونيز", p: 55 },
            { i: "كرواسون", p: 45 }
        ]
    },
    {
        id: "cafe_5",
        name: "كافيه قصر المنتزه",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAE9rwtXGD4NH8yBRk2LEHglDxldlrgOpsu0YYsG9KQEaJOnLGRKTLApzR5oUWXm8p9QoaHRpz9ohD2qPwhXnvgzIINH0F3bf0MbZMzCcQx1Z1T51b0IqJlYVjNHDsdbL6oyzeTHXw=w408-h544-k-no",
        map: "https://maps.app.goo.gl/xmK5U6cibjj92hu78",
        menu: [
            { i: "تشيكن برجر", p: 85 },
            { i: "فرايز", p: 35 },
            { i: "ساندوتش فيليه", p: 95 }
        ]
    },
    {
        id: "cafe_6",
        name: "Shuts Cafe - شوتس كافيه",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAH1d2YqmVYyBtAZpWsZ8RG6miHl9Q3j3k4dEgtC3tR0qfFGKRzIiCLzKcWG37L71IoYgPOKM-JmfsIk-bApp3cXZdi1bvavpjqOXoY7cws-kamwmp-CZPq-d29LfCASM6mvcfkK=w408-h306-k-no",
        map: "https://maps.app.goo.gl/6iFXzr2yqifstF2r8",
        menu: [
            { i: "مشويات مشكلة", p: 250 },
            { i: "سمك مشوي", p: 180 },
            { i: "سلطة طحينية", p: 45 }
        ]
    },
    {
        id: "cafe_7",
        name: "ZaCoffee",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAEALxV2Rqqu3iiOtt4SdopSlcGIBu1yg9SJO4Q-yggepsJa202MUlG8kL_RyyRUfPVsPxHaXHiX2Av6aWGnGwIwGo3vfUkkk-3HpEpravBa2GoqNTmopHMRiH1uQIYBlXnWNevf=w408-h408-k-no",
        map: "https://maps.app.goo.gl/4FW2EViXFEPx4tmq5",
        menu: [
            { i: "لاتيه", p: 65 },
            { i: "كابتشينو", p: 70 },
            { i: "براونيز", p: 55 }
        ]
    },
    {
        id: "cafe_8",
        name: "Porto Cafe",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAFYqgGzfUyWUTR9M_6hcl3TdcT30mkRjlU1wm7azWEMRv0I6FPZVUxvKc3Xc4VBf_ZrpHQCDY7S6H0GQ36fI1iJ3SrBWJKyqKGqROLtASRElabh5bU2EeHpCLt5FiGcUtAOvpuq=w408-h544-k-no",
        map: "https://maps.app.goo.gl/NNjbmnYVf3JwNGxcA",
        menu: [
            { i: "قهوة تركي", p: 35 },
            { i: "وافل نوتيلا", p: 85 },
            { i: "ميكس بيري", p: 60 }
        ]
    },
    {
        id: "cafe_9",
        name: "فريسكو كافيه",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHqHsGF5vRULOrMrESMa-xQhPUQrj6sGiIjaHClAibD6FyASSuCuurydwsd2meBBsUyJw-mlLR6ecIbSRyb7_grFRYiMem6O5rn5emufpbndt0i_GttGi-rea7yeHXl8TCOvvZ-tQ=w426-h240-k-no",
        map: "https://maps.app.goo.gl/fqNvG4uCnW9LyWE16",
        menu: [
            { i: "فرابتشينو", p: 110 },
            { i: "موكا مثلجة", p: 95 }
        ]
    },
    {
        id: "cafe_10",
        name: "Elan lounge",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAGSHqofd7LVN7vjOLojFIlC9VBIaEI3SgAN6xmF--UH4rfFNRYVxzNev6jxbAxQq3rW0CM5R4TOEI3vhuvPoAUjjsZ_BcDO7zAb4bchHTjXC2VQqgGp2ghbK_VYE8P9PFsEkwKf0e84o4LI=w408-h544-k-no",
        map: "https://maps.app.goo.gl/vReTncP3aqMyHM8q7",
        menu: [
            { i: "اسبريسو", p: 40 },
            { i: "كرواسون", p: 50 }
        ]
    }
];


// ==========================
// Local Storage
// ==========================
let cafeFavs = JSON.parse(localStorage.getItem("cafeFavs")) || [];
let cafeReviews = JSON.parse(localStorage.getItem("cafeReviews")) || {};
let isCafeFavMode = false;


// ==========================
// عرض الكافيهات
// ==========================
function renderCafes() {
    const grid = document.getElementById("cafesGrid");
    const list = isCafeFavMode ? baseCafes.filter(c => cafeFavs.includes(c.id)) : baseCafes;

    if (list.length === 0 && isCafeFavMode) {
        grid.innerHTML = `
            <div style="grid-column:1/-1; text-align:center; padding:50px;">
                <h3>لا توجد كافيهات في المفضلات ☕</h3>
            </div>
        `;
        return;
    }

    grid.innerHTML = list.map((c, index) => {
        const isFav = cafeFavs.includes(c.id);
        return `
        <div class="rest-card">
            <button class="fav-btn ${isFav ? "active" : ""}" onclick="toggleCafeFav('${c.id}')">
                ${isFav ? "❤️" : "🤍"}
            </button>
            <img src="${c.img}" alt="${c.name}">
            <div class="rest-info">
                <h3>${c.name}</h3>
                <div class="btns">
                    <button onclick="openCafeMenu(${index})">☕ المنيو والتعليقات</button>
                    <a href="${c.map}" target="_blank">🗺️ الموقع</a>
                </div>
            </div>
        </div>
        `;
    }).join("");
}


// ==========================
// عرض المفضلة
// ==========================
function toggleCafeView() {
    isCafeFavMode = !isCafeFavMode;
    const btn = document.getElementById("cafeFavBtn");
    btn.innerText = isCafeFavMode ? "عرض كل الكافيهات 🏠" : "عرض المفضلات فقط ❤️";
    btn.classList.toggle("active-mode", isCafeFavMode);
    renderCafes();
}


// ==========================
// المفضلة
// ==========================
function toggleCafeFav(id) {
    cafeFavs = cafeFavs.includes(id)
        ? cafeFavs.filter(f => f !== id)
        : [...cafeFavs, id];
    localStorage.setItem("cafeFavs", JSON.stringify(cafeFavs));
    renderCafes();
}


// ==========================
// فتح المنيو
// ==========================
function openCafeMenu(index) {
    const c = baseCafes[index];
    const reviews = cafeReviews[c.id] || [];

    document.getElementById("modalTitle").innerText = c.name;
    document.getElementById("menuItemsList").innerHTML = `
        <h4>المشروبات والحلويات:</h4>
        ${c.menu.map(m => `
            <div class="m-item">
                <span>${m.i}</span>
                <b>${m.p} ج.م</b>
            </div>
        `).join("")}
        <hr>
        <h4>تقييمات الزوار:</h4>
        <div class="rev-form">
            <select id="starsCafe">
                <option value="5">⭐⭐⭐⭐⭐</option>
                <option value="4">⭐⭐⭐⭐</option>
            </select>
            <textarea id="commentCafe" placeholder="شاركنا رأيك..."></textarea>
            <button onclick="addCafeRev('${c.id}', ${index})">نشر</button>
        </div>
        <div class="rev-list">
            ${reviews.map(v => `
                <div class="comment">
                    <span>${"⭐".repeat(v.s)}</span>
                    <p>${v.t}</p>
                </div>
            `).join("")}
        </div>
    `;

    document.getElementById("menuModal").style.display = "flex";
}


// ==========================
// إضافة تعليق
// ==========================
function addCafeRev(id, index) {
    const stars = document.getElementById("starsCafe").value;
    const text = document.getElementById("commentCafe").value;

    if (!text.trim()) { alert("اكتب تعليق!"); return; }

    if (!cafeReviews[id]) cafeReviews[id] = [];
    cafeReviews[id].unshift({ s: parseInt(stars), t: text });

    localStorage.setItem("cafeReviews", JSON.stringify(cafeReviews));
    openCafeMenu(index);
}


// ==========================
// غلق الـ Modal
// ==========================
function closeModal() {
    document.getElementById("menuModal").style.display = "none";
}


// ==========================
// تشغيل الموقع
// ==========================
window.onload = renderCafes;


// ==========================
// إضافة كافيه جديد
// ==========================
let addDishCounter = 0;
let addImgData = null;

function openAddModal() {
    document.getElementById('add-modal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    document.getElementById('add-menu-list').innerHTML = '';
    addDishCounter = 0;
    addImgData = null;
    document.getElementById('add-img-preview').innerHTML = 'معاينة الصورة';
    document.getElementById('add-img-url').value = '';
    document.getElementById('add-name').value = '';
    document.getElementById('add-loc').value = '';
    addNewDish();
    addNewDish();
}

function closeAddModal() {
    document.getElementById('add-modal').style.display = 'none';
    document.body.style.overflow = '';
}

function addNewDish() {
    addDishCounter++;
    const id = addDishCounter;
    const row = document.createElement('div');
    row.id = 'add-dish-row-' + id;
    row.style.cssText = 'display:grid; grid-template-columns:1fr 100px 36px; gap:8px; margin-bottom:8px; align-items:center;';
    row.innerHTML = `
        <input type="text" placeholder="اسم الطبق" id="add-dish-name-${id}"
            style="padding:9px 12px; border:1px solid #ddd; border-radius:10px; font-size:13px; font-family:inherit; width:100%;" />
        <input type="text" placeholder="السعر" id="add-dish-price-${id}"
            style="padding:9px 12px; border:1px solid #ddd; border-radius:10px; font-size:13px; font-family:inherit; width:100%;" />
        <button onclick="removeAddDish(${id})"
            style="background:none; border:1px solid #eee; border-radius:10px; width:36px; height:36px; cursor:pointer; color:#e74c3c; font-size:16px;">✕</button>
    `;
    document.getElementById('add-menu-list').appendChild(row);
}

function removeAddDish(id) {
    document.getElementById('add-dish-row-' + id)?.remove();
}

function previewAddImg() {
    const url = document.getElementById('add-img-url').value.trim();
    const preview = document.getElementById('add-img-preview');
    addImgData = null;
    if (url) {
        preview.innerHTML = `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;"
            onerror="this.parentElement.innerHTML='<span style=color:#e74c3c>رابط غلط</span>'" />`;
    } else {
        preview.innerHTML = 'معاينة الصورة';
    }
}

function handleAddFile() {
    const file = document.getElementById('add-img-file').files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        addImgData = e.target.result;
        document.getElementById('add-img-url').value = '';
        document.getElementById('add-img-preview').innerHTML =
            `<img src="${addImgData}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;" />`;
    };
    reader.readAsDataURL(file);
}

function saveNewRestaurant() {
    const name = document.getElementById('add-name').value.trim();
    const imgUrl = document.getElementById('add-img-url').value.trim();
    const image = addImgData || imgUrl || 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=500';
    const location = document.getElementById('add-loc').value.trim() || '#';

    if (!name) { alert('اكتب اسم الكافيه'); return; }

    const menu = [];
    for (let i = 1; i <= addDishCounter; i++) {
        const dishEl = document.getElementById('add-dish-name-' + i);
        const priceEl = document.getElementById('add-dish-price-' + i);
        if (dishEl && dishEl.value.trim()) {
            menu.push({
                i: dishEl.value.trim(),
                p: priceEl?.value.trim() || 0
            });
        }
    }

    const newCafe = {
        id: 'cafe_' + Date.now(),
        name,
        img: image,
        map: location,
        menu
    };

    baseCafes.push(newCafe);
    renderCafes();
    closeAddModal();
    alert(`✅ تم إضافة "${name}" بنجاح!`);
}

document.getElementById('add-modal').addEventListener('click', function(e) {
    if (e.target === this) closeAddModal();
});