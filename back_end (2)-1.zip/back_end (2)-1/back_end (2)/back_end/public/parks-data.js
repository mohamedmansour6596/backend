

// ============================================================
//  🌳 مدير المنتزهات — النسخة النهائية المدمجة
//  يجمع بين المنتزهات الأصلية + المنتزهات المضافة من localStorage
// ============================================================

// ─── المنتزهات الأصلية الثابتة ───
const ORIGINAL_PARKS = [
    {
        id: "park_1",
        name: "قريه أسيوط التكنولوجيا، الزكيه",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAF65Grxn_WC4cqoy5rVaV6SmSVAhTfwo5Jvi87ngV0Lwyhxiuzr7yZUuqqMxgaCf-jyG-uXmL3bqzs15v3F7PFToJpDV03vkaTpSKWWuqDqlqsNz5BzsQH8ZtxvJ89Iayz0wO4=w408-h272-k-no",
        map: "https://maps.app.goo.gl/q9BSDr3pq8FzdwhN7",
        menu: [{ i: "تذكرة الدخول", p: 10 }]
    },
    {
        id: "park_2",
        name: "محمية وادي الاسيوطي",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAFuakOjolMYa-9jxT8yY9MzRMqYfTAvC9UtO5bgf8asnLBEIpWqP-Y9FkfYC6PNqRZGhH9nZfio7qRWuxd6CSQo-X4thtAAm2N-O83WmiiqkivOt6zpXy6Kvk8-IbPZi3zJ2baStA=w408-h272-k-no",
        map: "https://maps.app.goo.gl/fnvLZBavXyjexfb69",
        menu: [{ i: "تذكرة دخول", p: 5 }]
    },
    {
        id: "park_3",
        name: "حديقة ناصر (الحيوان)",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHu0aWufHyh9Rh86caFWiquAXuw7SwAtzNuS3gID9-oW05M4r4IxAODq8Y9JH5zecsZvMmQV8fyAU9GGT2IBm5Nrrw7PWlPdzlpjdIUuGZyAlJchck3nKN9V5OFBmk2pMXdHemT=w408-h260-k-no",
        map: "https://maps.app.goo.gl/4wGnCAQtUxMEZFiM8",
        menu: [{ i: "تذكرة الدخول", p: 10 }]
    },
    {
        id: "park_4",
        name: "حديقة الربوة",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAG1rHfagkU9dCteRzLFVGKYjpjRdW5HAeyLX3O4nri_PPkoDn_0DCxl-gpKxk-zG7DWuDg0cZJ0f3brxQQbadE8ZKb0nIgOtXUHu6eqU8sqHc3fW-mU5vWlpv9wqvL6AHROJ7whrQ=w408-h544-k-no",
        map: "https://maps.app.goo.gl/mecSBXAuzg996Z5v7",
        menu: [{ i: "تذكرة دخول", p: 5 }]
    },
    {
        id: "park_5",
        name: "حديقة الفردوس",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAEk_GFGTkMJqpwNqX3a88KqQdCtgxdeZtLcX-1m6NCWXU4aBi-EdSHsxlqHHSnWy5M6yGTcK-I2sKcXHyYfHuEUwQQ3AAIi-FeSiUkjVLdtptrt0j6Quif9cdw0JSrofytOKlrO=w408-h303-k-no",
        map: "https://maps.app.goo.gl/cQrcKPn5KPGcdNhj9",
        menu: [{ i: "تذكرة الدخول", p: 10 }]
    },
    {
        id: "park_6",
        name: "فوفوزيلا بارك",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHJ15Ex8VRYTGmFIFxnqjuQndAONyjG7rFmFhqJraTTTpYjZARDLOCwJkErzL3dPuVwH28lvPoaRSCMbCGRrxXnvJTVlpK7_CMiK560i9MbEHX_N1Uo6AKgxHEEJ9qsPNZtEOg=w408-h306-k-no",
        map: "https://maps.app.goo.gl/iKe1Pie9r45MsHrV7",
        menu: [{ i: "تذكرة دخول", p: 5 }]
    },
    {
        id: "park_7",
        name: "X.play park",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAH39iXtpOcO2IBl936ymyYhmDd_CJilWWnUEyMAknKJkPDRrlzUnQebRTkvWx3EWo-ibEGOXRg1FA_cswaQe7cuNBjwuKg5KVeUOHGPYicgrTjxUzZItZ-QyvD4Ydvfz2RxjKA=w519-h240-k-no",
        map: "https://maps.app.goo.gl/1W3KnkCq6i6XqHCs5",
        menu: [{ i: "تذكرة الدخول", p: 100 }]
    },
    {
        id: "park_8",
        name: "حديقة أميرة مول",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAEMkV2BWzACTHjZnEt0ocdhpoCHmGYBdWEXhS1AiDIE9qnqpvTec1fW9Q0gfSW_AqDugm5Xs_DkgYrOtP6t-R2vubGDRCzoVNmRpievPpJr58tnLCCZLQliss2-64StRMOoo2bS=w408-h306-k-no",
        map: "https://maps.app.goo.gl/9zPHop3SX1MUm3739",
        menu: []
    },
    {
        id: "park_9",
        name: "الابراهيمية",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHaYimV48IgXSDAGjB-HgsDoDumBic0o2VTX7y2AfXlHRoQaFH_tcfMVR91J0XD_9GsF0Y6OOSVM1sXQ54EiqzhBqfWpZ9Uh0HNBiYoc7A90D7jPMsuZ5dcZ_aPM8t3Cve6hGc=w426-h240-k-no",
        map: "https://maps.app.goo.gl/3MhbtsHPGzVJXd9a8",
        menu: [{ i: "تذكرة الدخول", p: 10 }]
    },
    {
        id: "park_10",
        name: "قصر اليكسان باشا",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAF-1CsLE1ahoWBtDOaktrC5ILifzzsYI1YVHwQg56LMj6X_q-_GSTgolNmdirCRhNS_p9Eeq_RiqX0U4x0x9ztfdIUjtoixn8TefJ7PyY0lM_YSpw0goUy5gu8n23YwPw-LOwwA=w408-h291-k-no",
        map: "https://maps.app.goo.gl/ZXpPf5DZheiCegUBA",
        menu: [{ i: "تذكرة دخول", p: 5 }]
    }
];

// ─── مفاتيح localStorage ───
const CUSTOM_PARKS_KEY = "custom_parks";   // المنتزهات المضافة يدوياً
const DELETED_PARKS_KEY = "deleted_parks"; // المنتزهات الأصلية المحذوفة
const FAV_KEY = "parkFavs";
const REVIEWS_KEY = "parkReviews";

// ─── الحالة العامة ───
let parkFavs = JSON.parse(localStorage.getItem(FAV_KEY)) || [];
let parkReviews = JSON.parse(localStorage.getItem(REVIEWS_KEY)) || {};
let isParkFavMode = false;
let addParkImgData = null;

// ============================================================
//  دوال الـ Storage
// ============================================================

/** إرجاع المنتزهات المضافة يدوياً */
function getCustomParks() {
    try { return JSON.parse(localStorage.getItem(CUSTOM_PARKS_KEY)) || []; }
    catch { return []; }
}

/** حفظ المنتزهات المضافة يدوياً */
function saveCustomParks(list) {
    localStorage.setItem(CUSTOM_PARKS_KEY, JSON.stringify(list));
}

/** إرجاع IDs المنتزهات الأصلية المحذوفة */
function getDeletedOriginals() {
    try { return JSON.parse(localStorage.getItem(DELETED_PARKS_KEY)) || []; }
    catch { return []; }
}

/** حفظ ID منتزه أصلي محذوف */
function markOriginalDeleted(id) {
    const deleted = getDeletedOriginals();
    if (!deleted.includes(id)) {
        deleted.push(id);
        localStorage.setItem(DELETED_PARKS_KEY, JSON.stringify(deleted));
    }
}

/**
 * الدالة الرئيسية — تجمع الأصليين (غير المحذوفين) + المضافين
 */
function getAllParks() {
    const deleted = getDeletedOriginals();
    const originals = ORIGINAL_PARKS.filter(p => !deleted.includes(p.id));
    const customs = getCustomParks();
    return [...originals, ...customs];
}

// ============================================================
//  عرض المنتزهات
// ============================================================

function renderParks() {
    const grid = document.getElementById('parksGrid');
    if (!grid) return;

    let list = getAllParks();
    if (isParkFavMode) list = list.filter(p => parkFavs.includes(p.id));

    if (list.length === 0) {
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:50px;">
            <h3>${isParkFavMode ? 'لا توجد منتزهات في المفضلات 🌳' : 'لا توجد منتزهات بعد'}</h3>
        </div>`;
        return;
    }

    const allParks = getAllParks(); // للحصول على الـ index الصحيح

    grid.innerHTML = list.map((p) => {
        const isFav = parkFavs.includes(p.id);
        const isCustom = p.id.toString().startsWith('park_custom_');
        const originalIndex = allParks.findIndex(item => item.id === p.id);

        return `
        <div class="rest-card">
            <button class="fav-btn ${isFav ? 'active' : ''}" onclick="toggleParkFav('${p.id}', '${p.name.replace(/'/g, "\\'")}')">
                ${isFav ? '❤️' : '🤍'}
            </button>
            ${isCustom ? `<button onclick="deletePark('${p.id}')" style="position:absolute;top:10px;left:10px;background:rgba(0,0,0,0.5);color:#fff;border:none;border-radius:50%;width:30px;height:30px;cursor:pointer;font-size:14px;z-index:2;">🗑</button>` : ''}
            <img src="${p.img}" alt="${p.name}" onerror="this.src='https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=500'">
            <div class="rest-info">
                <h3>${p.name}</h3>
                ${p.loc ? `<p>📍 ${p.loc}</p>` : ''}
                <div class="btns">
                    ${(p.menu && p.menu.length) ? `<button onclick="openParkMenu(${originalIndex})">🌳 الأنشطة والأسعار</button>` : ''}
                    <a href="${p.map}" target="_blank">🗺️ الموقع</a>
                </div>
            </div>
        </div>`;
    }).join('');
}

// ============================================================
//  المفضلة
// ============================================================

async function toggleParkFav(id, name) {
    const userEmail = localStorage.getItem('user_email');

    if (parkFavs.includes(id)) {
        parkFavs = parkFavs.filter(f => f !== id);
    } else {
        parkFavs.push(id);
        if (userEmail) {
            try {
                await fetch('/api/favorites/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: userEmail, placeName: name })
                });
            } catch (err) {
                console.error("عطل في السيرفر:", err);
            }
        } else {
            alert("سجل دخول عشان تلاقي المنتزهات دي محفوظة في حسابك!");
        }
    }

    localStorage.setItem(FAV_KEY, JSON.stringify(parkFavs));
    renderParks();
}

function toggleParkView() {
    isParkFavMode = !isParkFavMode;
    const btn = document.getElementById('parkFavBtn');
    if (btn) {
        btn.innerText = isParkFavMode ? "عرض كل المنتزهات 🌳" : "عرض المفضلات فقط ❤️";
        btn.classList.toggle('active-mode', isParkFavMode);
    }
    renderParks();
}

// ============================================================
//  Modal الأنشطة والتقييمات
// ============================================================

function openParkMenu(idx) {
    const allParks = getAllParks();
    const p = allParks[idx];
    if (!p) return;

    const reviews = parkReviews[p.id] || [];
    const menuHTML = (p.menu && p.menu.length)
        ? p.menu.map(m => `<div class="m-item"><span>${m.i}</span><b>${m.p} ج.م</b></div>`).join('')
        : '<p style="color:#999;font-size:13px;">لا توجد أنشطة مسجلة</p>';

    document.getElementById('modalTitle').innerText = p.name;
    document.getElementById('menuItemsList').innerHTML = `
        <h4>الخدمات المتاحة:</h4>
        ${menuHTML}
        <hr>
        <h4>آراء الزوار:</h4>
        <div class="rev-form">
            <select id="starsPark">
                <option value="5">⭐⭐⭐⭐⭐</option>
                <option value="4">⭐⭐⭐⭐</option>
                <option value="3">⭐⭐⭐</option>
                <option value="2">⭐⭐</option>
                <option value="1">⭐</option>
            </select>
            <textarea id="commentPark" placeholder="اكتب تجربتك في المنتزه..."></textarea>
            <button onclick="addParkRev('${p.id}', ${idx})">نشر التقييم</button>
        </div>
        <div class="rev-list">
            ${reviews.map(v => `<div class="comment"><span>${"⭐".repeat(v.s)}</span><p>${v.t}</p></div>`).join('')}
        </div>
    `;
    document.getElementById('menuModal').style.display = 'flex';
}

function addParkRev(id, idx) {
    const s = document.getElementById('starsPark').value;
    const t = document.getElementById('commentPark').value;
    if (!t.trim()) return alert("اكتب تعليق!");
    if (!parkReviews[id]) parkReviews[id] = [];
    parkReviews[id].unshift({ s: parseInt(s), t });
    localStorage.setItem(REVIEWS_KEY, JSON.stringify(parkReviews));
    openParkMenu(idx);
}

function closeModal() {
    document.getElementById('menuModal').style.display = 'none';
}

// ============================================================
//  حذف منتزه
//  - الأصلي: يُحفظ ID في deleted_parks (لا يظهر مجدداً)
//  - المضاف: يُحذف من custom_parks
// ============================================================

function deletePark(id) {
    if (!confirm("هل تريد حذف هذا المنتزه؟")) return;

    const isOriginal = ORIGINAL_PARKS.some(p => p.id === id);

    if (isOriginal) {
        markOriginalDeleted(id);
    } else {
        const customs = getCustomParks().filter(p => p.id != id);
        saveCustomParks(customs);
    }

    // احذفه من المفضلة كمان
    parkFavs = parkFavs.filter(f => f !== id);
    localStorage.setItem(FAV_KEY, JSON.stringify(parkFavs));

    renderParks();
    showToast("🗑 تم حذف المنتزه");
}

// ============================================================
//  إضافة منتزه جديد
// ============================================================

function openAddModal() {
    document.getElementById('add-modal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    resetAddForm();
}

// دعم الاسمين القديم والجديد للـ modal
function openAddParkModal() { openAddModal(); }

function closeAddModal() {
    document.getElementById('add-modal').style.display = 'none';
    document.body.style.overflow = '';
}
function closeAddParkModal() { closeAddModal(); }

function resetAddForm() {
    ['add-name', 'add-park-name', 'add-img-url', 'add-park-img-url',
     'add-loc', 'add-park-loc', 'add-park-map'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });

    const menuList = document.getElementById('add-menu-list');
    if (menuList) menuList.innerHTML = '';

    ['add-img-preview', 'add-park-img-preview'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = 'معاينة الصورة';
    });

    ['add-img-file', 'add-park-img-file'].forEach(id => {
        const el = document.getElementById(id);
        if (el) { el.value = ''; delete el.dataset.base64; }
    });

    addParkImgData = null;
}

/* معاينة الصورة — رابط */
function previewAddImg() {
    const url = document.getElementById('add-img-url')?.value.trim()
              || document.getElementById('add-park-img-url')?.value.trim();
    const preview = document.getElementById('add-img-preview')
                 || document.getElementById('add-park-img-preview');
    addParkImgData = null;
    if (preview) preview.innerHTML = url
        ? `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;"
              onerror="this.parentElement.innerHTML='<span style=color:#e74c3c>رابط غلط</span>'" />`
        : 'معاينة الصورة';
}
function previewParkImg() { previewAddImg(); }

/* معاينة الصورة — ملف */
function handleAddFile() {
    const fileEl = document.getElementById('add-img-file')
                || document.getElementById('add-park-img-file');
    if (!fileEl || !fileEl.files[0]) return;
    const reader = new FileReader();
    reader.onload = e => {
        addParkImgData = e.target.result;
        fileEl.dataset.base64 = e.target.result;
        const preview = document.getElementById('add-img-preview')
                     || document.getElementById('add-park-img-preview');
        if (preview) preview.innerHTML =
            `<img src="${addParkImgData}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;" />`;
        // امسح الـ URL لو موجود
        ['add-img-url', 'add-park-img-url'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
    };
    reader.readAsDataURL(fileEl.files[0]);
}
function handleParkFile() { handleAddFile(); }

/* إضافة سطر مرفق/خدمة */
function addNewDish() {
    const list = document.getElementById('add-menu-list');
    if (!list) return;
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;align-items:center;';
    row.innerHTML = `
        <input type="text" placeholder="اسم الخدمة أو المرفق"
            style="flex:1;padding:9px 12px;border:1px solid #ddd;border-radius:10px;font-size:13px;font-family:inherit;" />
        <input type="number" placeholder="السعر" min="0"
            style="width:90px;padding:9px 12px;border:1px solid #ddd;border-radius:10px;font-size:13px;font-family:inherit;" />
        <button onclick="this.parentElement.remove()"
            style="background:#fee;border:none;border-radius:8px;padding:8px 12px;cursor:pointer;color:#c00;font-size:16px;">✕</button>
    `;
    list.appendChild(row);
}

/* حفظ المنتزه الجديد — يدعم كلا الـ modal القديم والجديد */
function saveNewRestaurant() { saveNewPark(); }

function saveNewPark() {
    // نقرأ من أي input متاح
    const name = (document.getElementById('add-name')?.value ||
                  document.getElementById('add-park-name')?.value || '').trim();
    const loc  = (document.getElementById('add-loc')?.value ||
                  document.getElementById('add-park-loc')?.value || '').trim();
    const mapUrl = (document.getElementById('add-loc')?.value ||
                    document.getElementById('add-park-map')?.value || '').trim();

    // الصورة: base64 > رابط > افتراضية
    const fileEl = document.getElementById('add-img-file') || document.getElementById('add-park-img-file');
    const urlEl  = document.getElementById('add-img-url')  || document.getElementById('add-park-img-url');
    const img = (fileEl?.dataset.base64)
              || (urlEl?.value.trim())
              || 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=500';

    if (!name) {
        alert('⚠️ اكتب اسم المنتزه');
        (document.getElementById('add-name') || document.getElementById('add-park-name'))?.focus();
        return;
    }

    // جمع المرافق من الصفوف المضافة
    const menuRows = document.querySelectorAll('#add-menu-list > div');
    const menu = Array.from(menuRows).map(row => {
        const inputs = row.querySelectorAll('input');
        const itemName = inputs[0]?.value.trim();
        const price = parseFloat(inputs[1]?.value) || 0;
        return itemName ? { i: itemName, p: price } : null;
    }).filter(Boolean);

    const newPark = {
        id: 'park_custom_' + Date.now(),
        name,
        loc: loc || '',
        img,
        map: mapUrl || `https://www.google.com/maps/search/${encodeURIComponent(name + " Assiut")}`,
        menu,
        addedAt: new Date().toLocaleDateString('ar-EG')
    };

    const customs = getCustomParks();
    customs.push(newPark);
    saveCustomParks(customs);

    closeAddModal();
    renderParks();
    showToast(`✅ تم حفظ "${name}" بنجاح!`);
}

// ============================================================
//  Toast إشعار
// ============================================================

function showToast(msg) {
    const toast = document.createElement('div');
    toast.textContent = msg;
    toast.style.cssText = `
        position:fixed;bottom:80px;left:50%;transform:translateX(-50%);
        background:#222;color:#fff;padding:12px 24px;border-radius:50px;
        font-size:14px;z-index:9999;opacity:0;transition:opacity .3s;
        font-family:inherit;white-space:nowrap;pointer-events:none;
    `;
    document.body.appendChild(toast);
    setTimeout(() => (toast.style.opacity = '1'), 10);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 400);
    }, 3000);
}

// ============================================================
//  التهيئة عند تحميل الصفحة
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    // إغلاق الـ modal بالنقر على الخلفية
    ['add-modal', 'add-park-modal'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('click', e => { if (e.target === el) closeAddModal(); });
    });

    renderParks();
});

// دعم window.onload كمان لو موجود
window.addEventListener('load', renderParks);