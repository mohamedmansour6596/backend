document.addEventListener('DOMContentLoaded', () => {
    // --- عناصر الـ Modal والزرار ---
    const modal = document.getElementById("signupModal");
    const btn = document.getElementById("openSignup");
    const span = document.getElementsByClassName("close-btn")[0];

    // --- 1. التحقق من وجود اسم محفوظ عند فتح الصفحة ---
    const savedName = localStorage.getItem('user_name');
    if (savedName) {
        btn.innerText = "أهلاً يا " + savedName;
    }

    // --- 2. وظائف الـ Modal ---
    btn.onclick = function() {
        // لو المستخدم مسجل قبل كده، الزرار مش هيفتح الفورم (ممكن نخليه يفتح بروفايل بعدين)
        if (!localStorage.getItem('user_name')) {
            modal.style.display = "block";
        } else {
            alert("إنت مسجل دخول بالفعل يا بطل!");
        }
    }

    span.onclick = function() {
        modal.style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // --- 3. إرسال البيانات للسيرفر وحفظ الحالة ---
    const signupForm = document.getElementById('signupForm');
    
    if (signupForm) {
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault(); // منع تحديث الصفحة

            // سحب البيانات من الحقول
            const name = document.getElementById('userName').value;
            const email = document.getElementById('userEmail').value;
            const password = document.getElementById('userPassword').value;

            try {
                // إرسال البيانات للسيرفر
                const response = await fetch('/api/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ name, email, password })
                });

                const data = await response.json();

                if (response.ok) {
                    alert("✅ " + data.message);
                    
                    // --- التعديل الجديد هنا ---
                    // 1. حفظ الاسم في ذاكرة المتصفح (localStorage)
                    localStorage.setItem('user_name', name);
                    
                    // 2. تغيير نص الزرار في الصفحة فوراً
                    btn.innerText = "أهلاً يا " + name;

                    // 3. قفل النافذة وتفريغ الفورم
                    modal.style.display = "none";
                    signupForm.reset();
                } else {
                    // هنا هيظهرلك لو الإيميل متكرر مثلاً زي ما حصل معاك
                    alert("❌ " + data.message);
                }
            } catch (error) {
                console.error("Error:", error);
                alert("تأكد إن السيرفر شغال يا عمرو!");
            }
        });
    }
});
// 1. قاعدة بيانات تجريبية للأماكن في أسيوط (تقدر تزود عليها براحتك)
const places = [
  { name: "مول الوطنية", category: "Shopping", sub: "Malls", desc: "أشهر مولات أسيوط للتسوق والملابس" },
  { name: "حديقة الفردوس", category: "Parks", sub: "Green Space", desc: "مكان هادئ ومناسب للعائلات على النيل مباشرة" },
  { name: "سينما رينيسانس", category: "Entertainment", sub: "Cinema", desc: "أحدث الأفلام العربية والأجنبية في أسيوط" },
  { name: "مطعم بريمو Primo", category: "Restaurants", sub: "Burgers", desc: "من أقوى مطاعم البرجر والوجبات السريعة" },
  { name: "كافيه بريستو Presto", category: "Cafes", sub: "Espresso", desc: "مكان رايق لشرب القهوة والمذاكرة" },
  { name: "قصر ثقافة أسيوط", category: "Entertainment", sub: "Games", desc: "فعاليات ثقافية وعروض مسرحية ممتعة" }
];

// 2. تمسيك العناصر من الـ HTML
const searchBtn = document.querySelector('.search-btn');
const searchInput = document.getElementById('searchInput');
const searchResultsContainer = document.getElementById('searchResults');

// 3. دالة البحث والعرض
function performSearch() {
  const query = searchInput.value.trim().toLowerCase();
  
  // لو المستخدم داس بحث وهو مش كاتب حاجة، نفضي المكان ونقفل الدالة
  if (query === "") {
    searchResultsContainer.innerHTML = "";
    searchResultsContainer.style.display = "none";
    return;
  }

  // تصفية الأماكن بناءً على اسم المكان أو التصنيف أو الوصف
  const filteredPlaces = places.filter(place => {
    return (
      place.name.toLowerCase().includes(query) ||
      place.category.toLowerCase().includes(query) ||
      place.desc.toLowerCase().includes(query)
    );
  });

  // عرض النتائج في الـ HTML
  searchResultsContainer.innerHTML = ""; // تصفية النتائج القديمة
  searchResultsContainer.style.display = "grid"; // إظهار الحاوية

  if (filteredPlaces.length === 0) {
    searchResultsContainer.innerHTML = `<p class="no-results">للأسف مفيش أماكن بالاسم ده في أسيوط حالياً 😢</p>`;
    return;
  }

  // رسم بطاقات الأماكن (Cards)
  filteredPlaces.forEach(place => {
    const card = document.createElement('div');
    card.className = 'place-card';
    card.innerHTML = `
      <div class="card-header">
        <h3>${place.name}</h3>
        <span class="badge">${place.sub}</span>
      </div>
      <p class="card-desc">${place.desc}</p>
    `;
    searchResultsContainer.appendChild(card);
  });
}

// 4. ربط الدالة بزرار البحث والضغط على Enter
searchBtn.addEventListener('click', performSearch);
searchInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    performSearch();
  }
});