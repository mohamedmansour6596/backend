// ============================================================
//  🛍️ مدير التسوق — shops-manager-final.js
//  يجمع المحلات الأصلية + المضافة من localStorage
// ============================================================

// ─── المحلات الأصلية الثابتة ───
const ORIGINAL_SHOPS = [
    {
        id: "shop_1",
        name: "هابي مول للتسوق",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAED1PqB6fdbiMNbeuqHEThB6Nv4Cr9WG9bZgV6Ea-qvEQXWHrLcvKWzvZcODOUkRWJFGm7L7Yi3C_DAKrJitRgXZ-j95Zbt18Gd__yYL1N1aeFK25XSiN_xB8vFbTXNOFA45Hkw=w203-h135-k-no",
        map: "https://maps.app.goo.gl/Tu5hDACVvK6TQPMs5",
        menu: [
            { i: "قسم الملابس الرجالي", p: "أسعار متنوعة" },
            { i: "قسم الأحذية", p: "ماركات أصلية" }
        ]
    },
    {
        id: "shop_2",
        name: "ستار مول",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAGgTYeVLqlHdWbJlKPEaTUI2B2-wr3_kNH25hOec63N5_Ef-0tRHO3huLy-MQIJIBxZxMCQcQqfMHTm0bWaQ6gbCJw-RtZVHPZVcMMKSjkpuQENuQ98NTldRYP1o_pmCKLNFM-XnRdlWFMW=w408-h306-k-no",
        map: "https://maps.app.goo.gl/jJhPiLkkex1YtEF59",
        menu: [
            { i: "قسم الملابس الرجالي", p: "أسعار متنوعة" },
            { i: "قسم الأحذية", p: "ماركات أصلية" }
        ]
    },
    {
        id: "shop_3",
        name: "LC Waikiki Assyut",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAF-fyEXfTarbp_16Qlp4vsgLAHtixVNVlWjS4_FIHJ7AcbRTjKmTJjplN4dUYPJOurnaHxRvXoL0-u9gwMOtBuzx8d5U2vhMcom561dhhO9qp0lcLDuLMJZyqq4c3R5x83irgghrw=w408-h544-k-no",
        map: "https://maps.app.goo.gl/h4fmb7GrQG3WWzjy8",
        menu: [
            { i: "ملابس داخلية", p: 100 }
        ]
    },
    {
        id: "shop_4",
        name: "صيدناوي مول",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAFUdiYj-siTjPROOiv8AdEo-rxqtwLZeA-2C4HFiFkDt-TU2VKnuWKIMYNJTX4Ho3aKLs7xt-13M3puVwb5_l7K6_beeRAQ7-ZuyveWF4N9IbqgW-T3R2pFR5bClCrpYhnKqkd9=w426-h240-k-no",
        map: "https://maps.app.goo.gl/i4wifE6N7oFe3DHR6",
        menu: [
            { i: "أدوات منزلية", p: "أسعار جملة" },
            { i: "أجهزة كهربائية", p: "ضمان معتمد" }
        ]
    },
    {
        id: "shop_5",
        name: "مول الوطنية",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAH2fUIkPUQj-VPsBqJo2CP3AodgwdBkR_ICpNY2agbNr_zH7m19SHGuGy7ojtnS7jYYW9lFAyy-IzSwFnNw_MT8NlTICTJMBHkA2ZqNNDYsDIAdgcwl5uzInrEBGeun8Q774ivi=w203-h152-k-no",
        map: "https://maps.app.goo.gl/U1NfE8ecDCj34PKu8",
        menu: [
            { i: "ملابس", p: "متنوعة" },
            { i: "أحذية", p: "متنوعة" }
        ]
    },
    {
        id: "shop_6",
        name: "in&out cafee",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAG1GOplcwnEsAtUgzBApFJ_yXuKnN5nRahW5gVyEfilCP4VxlffW80w1d6t2pcCJMFwBIFXx052KnaF7FoBu10dhm5X2sJjxMmJej74yrUudBkCXa1YnTbXziGJ6A3SFeBf4RBX=w408-h306-k-no",
        map: "https://maps.app.goo.gl/WpdFWj5U2hPucbCX7",
        menu: [
            { i: "فساتين", p: "أسعار مختلفة" },
            { i: "إكسسوارات", p: "متنوعة" }
        ]
    },
    {
        id: "shop_7",
        name: "تاون تيم",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAHNMl8Ka_77X-bcP-UTAhTRa7v1BUpevRjxdpKWnd7-evGv-sBgP_pkuljJt7u8nWn4VZG3j6JDwDXMu-uZIIDMy_5pyRElU4rqUNj7ih_dnEc5qVtsVnk3i_uyFyPakyQUrJb4yA=w408-h306-k-no",
        map: "https://maps.app.goo.gl/JaEAn4efGsYn62Ds5",
        menu: [
            { i: "ملابس رجالي", p: "متنوعة" },
            { i: "تيشيرتات", p: "متنوعة" }
        ]
    },
    {
        id: "shop_8",
        name: "ديفاكتو",
        img: "https://lh3.googleusercontent.com/dclZ65ckt_wLefuV3G8aIOvGjuuE2okwmHfk31ieDUUFfB4v1oxh0ubL_QtZY0fx=w426-h240-k-no",
        map: "https://maps.app.goo.gl/2nAxYNk9vMz4YCr7A",
        menu: [
            { i: "ملابس رجالي", p: "متنوعة" },
            { i: "ملابس حريمي", p: "متنوعة" }
        ]
    },
    {
        id: "shop_9",
        name: "إل سي وايكيكي",
        loc: "سيتي مول",
        img: "https://lh3.googleusercontent.com/gps-cs-s/APNQkAF-fyEXfTarbp_16Qlp4vsgLAHtixVNVlWjS4_FIHJ7AcbRTjKmTJjplN4dUYPJOurnaHxRvXoL0-u9gwMOtBuzx8d5U2vhMcom561dhhO9qp0lcLDuLMJZyqq4c3R5x83irgghrw=w408-h544-k-no",
        map: "https://maps.app.goo.gl/LdDQcK6nJ9AhPoTA8",
        menu: [
            { i: "ملابس أطفال", p: "متنوعة" },
            { i: "ملابس عائلية", p: "متنوعة" }
        ]
    },
    {
        id: "shop_10",
        name: "بركات بلازا",
        img: "https://lh3.googleusercontent.com/UGLTRniEaYUnsbAO-B22-eEMboy5uGfz7xG5SCYzs1-WYQy3tlwIo2KETAzThzc=w426-h240-k-no",
        map: "https://maps.app.goo.gl/9znBLkCgz2GjRAkq5",
        menu: [
            { i: "أحذية", p: "متنوعة" },
            { i: "شنط", p: "متنوعة" }
        ]
    }
];

// ─── مفاتيح localStorage ───
const SHOP_CUSTOM_KEY  = "shop_custom";
const SHOP_DELETED_KEY = "shop_deleted";
const SHOP_FAVS_KEY    = "shopFavs";
const SHOP_REVIEWS_KEY = "shopReviews";

// ─── الحالة العامة ───
let shopFavs      = JSON.parse(localStorage.getItem(SHOP_FAVS_KEY))    || [];
let shopReviews   = JSON.parse(localStorage.getItem(SHOP_REVIEWS_KEY)) || {};
let isShopFavMode = false;
let shopAddImgData = null;

// ============================================================
//  دوال Storage
// ============================================================

function getCustomShops()    { try { return JSON.parse(localStorage.getItem(SHOP_CUSTOM_KEY))  || []; } catch { return []; } }
function saveCustomShops(l)  { localStorage.setItem(SHOP_CUSTOM_KEY, JSON.stringify(l)); }
function getDeletedShops()   { try { return JSON.parse(localStorage.getItem(SHOP_DELETED_KEY)) || []; } catch { return []; } }

function markShopDeleted(id) {
    const d = getDeletedShops();
    if (!d.includes(id)) { d.push(id); localStorage.setItem(SHOP_DELETED_KEY, JSON.stringify(d)); }
}

/** كل المحلات = الأصليين (غير المحذوفين) + المضافين */
function getAllShops() {
    const deleted = getDeletedShops();
    return [
        ...ORIGINAL_SHOPS.filter(s => !deleted.includes(s.id)),
        ...getCustomShops()
    ];
}

// ============================================================
//  عرض المحلات
// ============================================================

function renderShops() {
    const grid = document.getElementById('shopsGrid');
    if (!grid) return;

    let list = getAllShops();
    if (isShopFavMode) list = list.filter(s => shopFavs.includes(s.id));

    if (list.length === 0) {
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:50px;">
            <h3>${isShopFavMode ? 'حقيبة المفضلات فارغة 🛍️' : 'لا توجد محلات بعد'}</h3>
        </div>`;
        return;
    }

    const all = getAllShops();
    grid.innerHTML = list.map(s => {
        const isFav    = shopFavs.includes(s.id);
        const isCustom = String(s.id).startsWith('shop_custom_');
        const idx      = all.findIndex(item => item.id === s.id);
        return `
        <div class="rest-card">
            <button class="fav-btn ${isFav ? 'active' : ''}"
                onclick="toggleShopFav('${s.id}', '${s.name.replace(/'/g,"\\'")}')">
                ${isFav ? '❤️' : '🤍'}
            </button>
            ${isCustom ? `
            <button onclick="deleteShop('${s.id}')"
                style="position:absolute;top:10px;left:10px;background:rgba(0,0,0,0.55);color:#fff;
                       border:none;border-radius:50%;width:30px;height:30px;cursor:pointer;font-size:14px;z-index:2;">
                🗑
            </button>` : ''}
            <img src="${s.img}" alt="${s.name}"
                onerror="this.src='https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?w=500'">
            <div class="rest-info">
                <h3>${s.name}</h3>
                ${s.loc ? `<p>📍 ${s.loc}</p>` : ''}
                <div class="btns">
                    <button onclick="openShopMenu(${idx})">🛍️ الأقسام والخدمات</button>
                    <a href="${s.map}" target="_blank">🗺️ الموقع</a>
                </div>
            </div>
        </div>`;
    }).join('');
}

// ============================================================
//  المفضلة
// ============================================================

async function toggleShopFav(id, name) {
    const userEmail = localStorage.getItem('user_email');

    if (shopFavs.includes(id)) {
        shopFavs = shopFavs.filter(f => f !== id);
    } else {
        shopFavs.push(id);
        if (userEmail) {
            try {
                await fetch('/api/favorites/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: userEmail, placeName: name })
                });
            } catch (err) { console.error("خطأ في السيرفر:", err); }
        } else {
            alert("سجل دخول عشان المفضلات تتحفظ في حسابك!");
        }
    }

    localStorage.setItem(SHOP_FAVS_KEY, JSON.stringify(shopFavs));
    renderShops();
}

function toggleShopView() {
    isShopFavMode = !isShopFavMode;
    const btn = document.getElementById('shopFavBtn');
    if (btn) {
        btn.innerText = isShopFavMode ? "عرض كل المحلات 🏠" : "عرض المفضلات فقط ❤️";
        btn.classList.toggle('active-mode', isShopFavMode);
    }
    renderShops();
}

// ============================================================
//  Modal الأقسام والتقييمات
// ============================================================

function openShopMenu(idx) {
    const all = getAllShops();
    const s   = all[idx];
    if (!s) return;

    const reviews = shopReviews[s.id] || [];
    document.getElementById('modalTitle').innerText = s.name;
    document.getElementById('menuItemsList').innerHTML = `
        <h4>أقسام المتجر:</h4>
        ${s.menu && s.menu.length
            ? s.menu.map(m => `<div class="m-item"><span>${m.i}</span><b>${m.p}</b></div>`).join('')
            : '<p style="color:#999;font-size:13px;">لا توجد أقسام مسجلة</p>'}
        <hr>
        <h4>آراء المتسوقين:</h4>
        <div class="rev-form">
            <select id="starsShop">
                <option value="5">⭐⭐⭐⭐⭐</option>
                <option value="4">⭐⭐⭐⭐</option>
                <option value="3">⭐⭐⭐</option>
                <option value="2">⭐⭐</option>
                <option value="1">⭐</option>
            </select>
            <textarea id="commentShop" placeholder="شاركنا رأيك في تجربة التسوق هنا..."></textarea>
            <button onclick="addShopRev('${s.id}', ${idx})">إرسال التعليق</button>
        </div>
        <div class="rev-list">
            ${reviews.map(v => `<div class="comment"><span>${"⭐".repeat(v.s)}</span><p>${v.t}</p></div>`).join('')}
        </div>
    `;
    document.getElementById('menuModal').style.display = 'flex';
}

function addShopRev(id, idx) {
    const s = document.getElementById('starsShop').value;
    const t = document.getElementById('commentShop').value.trim();
    if (!t) return alert("اكتب تعليقك أولاً!");
    if (!shopReviews[id]) shopReviews[id] = [];
    shopReviews[id].unshift({ s: parseInt(s), t });
    localStorage.setItem(SHOP_REVIEWS_KEY, JSON.stringify(shopReviews));
    openShopMenu(idx);
}

function closeModal() {
    document.getElementById('menuModal').style.display = 'none';
}

// ============================================================
//  حذف محل
// ============================================================

function deleteShop(id) {
    if (!confirm("هل تريد حذف هذا المحل؟")) return;

    const isOriginal = ORIGINAL_SHOPS.some(s => s.id === id);
    if (isOriginal) {
        markShopDeleted(id);
    } else {
        saveCustomShops(getCustomShops().filter(s => s.id != id));
    }

    shopFavs = shopFavs.filter(f => f !== id);
    localStorage.setItem(SHOP_FAVS_KEY, JSON.stringify(shopFavs));

    renderShops();
    showShopToast("🗑 تم حذف المحل");
}

// ============================================================
//  إضافة محل جديد
// ============================================================

function openAddModal() {
    document.getElementById('add-modal').style.display = 'block';
    document.body.style.overflow = 'hidden';
    resetShopForm();
}

function closeAddModal() {
    document.getElementById('add-modal').style.display = 'none';
    document.body.style.overflow = '';
}

function resetShopForm() {
    ['add-name', 'add-img-url', 'add-loc'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    const menuList = document.getElementById('add-menu-list');
    if (menuList) menuList.innerHTML = '';
    const preview = document.getElementById('add-img-preview');
    if (preview) preview.innerHTML = 'معاينة الصورة';
    const fileInput = document.getElementById('add-img-file');
    if (fileInput) { fileInput.value = ''; delete fileInput.dataset.base64; }
    shopAddImgData = null;
}

function previewAddImg() {
    const url     = document.getElementById('add-img-url')?.value.trim();
    const preview = document.getElementById('add-img-preview');
    shopAddImgData = null;
    if (preview) preview.innerHTML = url
        ? `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;"
              onerror="this.parentElement.innerHTML='<span style=color:#e74c3c>رابط غلط</span>'" />`
        : 'معاينة الصورة';
}

function handleAddFile() {
    const fileEl = document.getElementById('add-img-file');
    if (!fileEl?.files[0]) return;
    const reader = new FileReader();
    reader.onload = e => {
        shopAddImgData = e.target.result;
        fileEl.dataset.base64 = e.target.result;
        const preview = document.getElementById('add-img-preview');
        if (preview) preview.innerHTML =
            `<img src="${shopAddImgData}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;" />`;
        const urlEl = document.getElementById('add-img-url');
        if (urlEl) urlEl.value = '';
    };
    reader.readAsDataURL(fileEl.files[0]);
}

/* إضافة سطر قسم / منتج — الدالة اللي بينادي عليها الـ HTML */
function addNewProduct() {
    const list = document.getElementById('add-menu-list');
    if (!list) return;
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;align-items:center;';
    row.innerHTML = `
        <input type="text" placeholder="اسم القسم أو المنتج"
            style="flex:1;padding:9px 12px;border:1px solid #ddd;border-radius:10px;font-size:13px;font-family:inherit;" />
        <input type="text" placeholder="السعر أو الوصف"
            style="width:110px;padding:9px 12px;border:1px solid #ddd;border-radius:10px;font-size:13px;font-family:inherit;" />
        <button onclick="this.parentElement.remove()"
            style="background:#fee;border:none;border-radius:8px;padding:8px 12px;cursor:pointer;color:#c00;font-size:16px;">✕</button>
    `;
    list.appendChild(row);
}

/* حفظ المحل — الدالة اللي بينادي عليها الـ HTML */
function saveNewShop() {
    const name   = document.getElementById('add-name')?.value.trim();
    const loc    = document.getElementById('add-loc')?.value.trim();
    const fileEl = document.getElementById('add-img-file');
    const urlEl  = document.getElementById('add-img-url');
    const img    = fileEl?.dataset.base64 || urlEl?.value.trim()
                || 'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?w=500';

    if (!name) {
        alert('⚠️ اكتب اسم المحل');
        document.getElementById('add-name')?.focus();
        return;
    }

    const menuRows = document.querySelectorAll('#add-menu-list > div');
    const menu = Array.from(menuRows).map(row => {
        const inputs = row.querySelectorAll('input');
        const itemName = inputs[0]?.value.trim();
        const price    = inputs[1]?.value.trim() || 'متنوعة';
        return itemName ? { i: itemName, p: price } : null;
    }).filter(Boolean);

    const newShop = {
        id: 'shop_custom_' + Date.now(),
        name,
        loc: loc || '',
        img,
        map: loc || `https://www.google.com/maps/search/${encodeURIComponent(name + " Assiut")}`,
        menu,
        addedAt: new Date().toLocaleDateString('ar-EG')
    };

    const customs = getCustomShops();
    customs.push(newShop);
    saveCustomShops(customs);

    closeAddModal();
    renderShops();
    showShopToast(`✅ تم حفظ "${name}" بنجاح!`);
}

// ============================================================
//  Toast إشعار
// ============================================================

function showShopToast(msg) {
    const toast = document.createElement('div');
    toast.textContent = msg;
    toast.style.cssText = `
        position:fixed;bottom:80px;left:50%;transform:translateX(-50%);
        background:#222;color:#fff;padding:12px 24px;border-radius:50px;
        font-size:14px;z-index:9999;opacity:0;transition:opacity .3s;
        font-family:inherit;white-space:nowrap;pointer-events:none;
    `;
    document.body.appendChild(toast);
    setTimeout(() => (toast.style.opacity = '1'), 10);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 400); }, 3000);
}

// ============================================================
//  التهيئة
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('add-modal');
    if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeAddModal(); });
    renderShops();
});

window.addEventListener('load', renderShops);

