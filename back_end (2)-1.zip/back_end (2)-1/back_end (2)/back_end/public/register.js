const registerForm = document.getElementById('register-form');

if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // السطر ده أهم سطر عشان الصفحة متعملش Refresh
        
        // --- 1. جلب زرار الإرسال لتأمينه من الضغط المتكرر ---
        const submitButton = registerForm.querySelector('button[type="submit"]');

        // 2. جمع البيانات من الحقول
        const name = document.getElementById('reg-name').value;
        const email = document.getElementById('reg-email').value;
        const password = document.getElementById('reg-password').value;

        // --- 2.5 التحقق من طول الباسورد في الفرونت إند ---
        if (password.length !== 8) {
            alert("يا بطل، لازم كلمة المرور تكون 8 حروف أو أرقام على الأقل! 🛡️");
            return; // إيقاف العملية فوراً
        }

        console.log("جاري إرسال البيانات:", { name, email, password });

        try {
            // --- 3. قفل الزرار وتغيير النص فوراً لمنع الطلب المتكرر ---
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerText = "جاري التسجيل...";
            }

            // 4. إرسال الطلب للسيرفر
            const response = await fetch('http://localhost:3000/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ name, email, password })
            });

            const data = await response.json();

            if (response.ok) {
                console.log("✅ نجاح:", data.message);
                alert("تم التسجيل بنجاح يا بطل!");
                
                // --- حفظ البيانات عشان السيستم كله يشوفها ---
                localStorage.setItem('user_email', email); 
                localStorage.setItem('user_name', name);   
                localStorage.setItem('currentUser', JSON.stringify(data.user)); 
                // ----------------------------------------

                // التحويل لصفحة الهوم
                window.location.href = 'index.html'; 
            } else {
                console.error("❌ فشل:", data.message);
                alert(data.message); 
            }
        } catch (error) {
            console.error('❌ خطأ في الاتصال بالسيرفر:', error);
            alert('السيرفر مش بيرد، اتأكد إنك مشغله بـ node server.js');
        } finally {
            // --- 5. إعادة تفعيل الزرار في حال حدوث خطأ حتى يستطيع المستخدم المحاولة مجدداً ---
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.innerText = "تسجيل";
            }
        }
    });
} else {
    console.error("لم يتم العثور على فورم التسجيل! تأكد من وجود id='register-form'");
}