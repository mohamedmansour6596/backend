const mongoose = require('mongoose');
const Place = require('./model/Place'); //

mongoose.connect("mongodb://127.0.0.1:27017/data") //
    .then(async () => {
        console.log("🚀 جاري تنظيف الداتا بيز ونقل الأماكن الحقيقية للمانجو...");
        
        await Place.deleteMany({}); // مسح القديم لتجنب التكرار

        // 1. الكافيهات الحقيقية
        const baseCafes = [
            { name: "سيلانترو - Cilantro", loc: "ش الجمهورية", mapQuery: "Cilantro Assiut", img: "https://images.unsplash.com/photo-1509042239860-f550ce710b93", menu: [{i: "لاتيه", p: 65}, {i: "كابتشينو", p: 70}] },
            { name: "رويال جيت - Royal Jet", loc: "المشاية السفلى", mapQuery: "Royal Jet Assiut", img: "https://images.unsplash.com/photo-1554118811-1e0d58224f24", menu: [{i: "قهوة تركي", p: 35}, {i: "وافل نوتيلا", p: 85}] },
            { name: "ستارباكس - Starbucks (أسيوط)", loc: "داون تاون", mapQuery: "Starbucks Assiut", img: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb", menu: [{i: "فرابتشينو", p: 110}] },
            { name: "كافيه دو باريس", loc: "ش النميس", mapQuery: "Café de Paris Assiut", img: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085", menu: [{i: "اسبريسو", p: 40}] }
        ];

        // 2. أماكن الترفيه والشوبينج الحقيقية اللي بعتها
        const baseEntertainment = [
            { name: "سيتي مول", loc: "ش الهلالي", img: "https://images.unsplash.com/photo-1519567241046-7f570eee3ce6" },
            { name: "سينما رينيسانس", loc: "ش الجمهورية", img: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba" },
            { name: "توب سنتر", loc: "ش الجمهورية", img: "https://images.unsplash.com/photo-1441986300917-64674bd600d8" },
            { name: "بولينج سيتي", loc: "ش الهلالي", img: "https://images.unsplash.com/photo-1538510127047-9744fd6fa63a" },
            { name: "تيك توك ألعاب", loc: "ش النميس", img: "https://images.unsplash.com/photo-1534423839368-1791ffcdd26b" },
            { name: "ملاهي ناصر", loc: "الوليدية", img: "https://images.unsplash.com/photo-1533553901322-927943553755" },
            { name: "ذا هب - The Hub", loc: "أسيوط الجديدة", img: "https://images.unsplash.com/photo-1511886929837-354d827aae26" },
            
         { name: "قطونيل سنتر", loc: "ش النميس", img: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b" }
        
        ];


        
        const categories = ['restaurant', 'cafe', 'entertainment'];
        const allPlaces = [];

        categories.forEach(cat => {
            for (let i = 1; i <= 50; i++) {
                if (cat === 'cafe') {
                    let base = baseCafes[(i - 1) % baseCafes.length];
                    allPlaces.push({
                        name: i <= baseCafes.length ? base.name : `${base.name} (فرع ${i})`,
                        category: cat,
                        loc: base.loc,
                        img: base.img,
                        mapQuery: base.mapQuery || base.name,
                        menu: base.menu || [{i: "مشروب ترحيبي", p: 30}]
                    });
                } else if (cat === 'entertainment') {
                    let base = baseEntertainment[(i - 1) % baseEntertainment.length];
                    allPlaces.push({
                        name: i <= baseEntertainment.length ? base.name : `${base.name} (فرع ${i})`,
                        category: cat,
                        loc: base.loc,
                        img: base.img,
                        mapQuery: base.name + " Assiut",
                        menu: [{ i: "تذكرة دخول", p: 50 + i }]
                    });
                } else {
                    // المطاعم (تقدر تكرر نفس الحركة لو بعت بياناتهم)
                    allPlaces.push({
                        name: `مطعم رقم ${i}`,
                        category: 'restaurant',
                        loc: "أسيوط - وسط البلد",
                        img: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4",
                        mapQuery: "Assiut Restaurant",
                        menu: [{ i: "وجبة تجريبية", p: 100 + i }]
                    });
                }
            }
        });

        await Place.insertMany(allPlaces); //
        console.log(`✅ تم نقل ${allPlaces.length} مكان بنجاح!`);
        console.log("⭐ الكافيهات والترفيه الآن ببيانات حقيقية.");
        process.exit();
    })
    .catch(err => console.error("❌ خطأ:", err.message));