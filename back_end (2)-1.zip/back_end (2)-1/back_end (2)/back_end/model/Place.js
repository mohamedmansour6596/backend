const mongoose = require('mongoose');

const placeSchema = new mongoose.Schema({
    name: String,
    category: String, // 'restaurant', 'cafe', 'park', 'shopping'
    loc: String,
    img: String,
    mapQuery: String,
    menu: [{ i: String, p: Number }], // مصفوفة للأصناف والأسعار
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Place', placeSchema);