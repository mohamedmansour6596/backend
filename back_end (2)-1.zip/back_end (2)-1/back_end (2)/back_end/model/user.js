const mongoose = require('mongoose');

// تعريف شكل البيانات (Schema) الخاصة بالمستخدم
const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true // الإيميل لازم يكون فريد عشان نعرف نميز المستخدم
    },
    password: {
        type: String,
        required: true,
        minlength: [8, "يجب ألا يقل الرقم السري عن 8 أحرف أو أرقام!"]
    },
    // تعديل بسيط: جعلنا المفضلة مصفوفة من النصوص (أسماء الأماكن)
    // واستخدام [] بيسمح للمانجو تعرف إن دي قائمة
    favorites: {
        type: [String],
        default: [] // بتبدأ فاضية أول ما المستخدم يسجل
    }
});

// إنشاء الموديل وتصديره
const User = mongoose.model('User', userSchema);

module.exports = User;