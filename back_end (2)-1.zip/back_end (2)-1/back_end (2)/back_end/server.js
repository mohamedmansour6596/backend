const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const User = require("./model/user.js"); 

const app = express();

// --- 1. الإعدادات الأساسية (Middleware) ---
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- 2. الربط بقاعدة بيانات MongoDB ---
mongoose.connect("mongodb://127.0.0.1:27017/data")
    .then(() => console.log("✅ مبروك يا عمرو.. السيرفر اتربط بالمانجو تمام!"))
    .catch(err => console.error("❌ في مشكلة في ربط المانجو: ", err.message));

// --- 3. المسارات (Routes) ---

// أ- مسار التسجيل (Register)
app.post("/api/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;
        console.log("📥 محاولة تسجيل جديدة للاسم:", name);

        const newUser = new User({ 
            username: name, 
            email: email, 
            password: password,
            favorites: [] // بتبدأ مصفوفة فاضية
        });
        
        await newUser.save();
        console.log("✨ تم حفظ المستخدم في المانجو بنجاح!");
        res.status(201).json({ message: "تم التسجيل بنجاح يا بطل!" });

    } catch (error) {
        console.error("❌ فشل الحفظ بسبب:", error.message);
        res.status(400).json({ message: "فشل التسجيل: " + error.message });
    }
});

// ب- مسار إضافة للمفضلة (Add to Favorites) - الجديد! ⭐
app.post("/api/favorites/add", async (req, res) => {
    try {
        const { email, placeName } = req.body;

        if (!email || !placeName) {
            return res.status(400).json({ message: "البيانات ناقصة يا بطل!" });
        }

        // البحث عن المستخدم وتحديث مصفوفة المفضلة
        // $addToSet بتضمن إن المكان ميتكررش مرتين لنفس الشخص
        const updatedUser = await User.findOneAndUpdate(
            { email: email },
            { $addToSet: { favorites: placeName } },
            { new: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "المستخدم مش موجود!" });
        }

        console.log(`⭐ تم إضافة ${placeName} لمفضلة ${email}`);
        res.status(200).json({ message: "تمت الإضافة للمفضلة بنجاح! ⭐" });

    } catch (error) {
        console.error("❌ فشل إضافة المفضلة:", error.message);
        res.status(500).json({ message: "مشكلة في السيرفر: " + error.message });
    }
});

// ج- مسار عرض الصفحة الرئيسية
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'html.html'));
});

// د- مسارات الصفحات الأخرى
app.get("/restaurants", (req, res) => res.sendFile(path.join(__dirname, 'public', 'restaurants.html')));
app.get("/cafes", (req, res) => res.sendFile(path.join(__dirname, 'public', 'cafes.html')));

// هـ- مسار صفحة التوصيات الذكية (AI Recommender) 🤖
app.get("/recommender", (req, res) => res.sendFile(path.join(__dirname, 'public', 'recommender.html')));

// --- 4.

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 السيرفر شغال دلوقتي على بورت ${PORT}`);
    console.log(`💡 افتح اللينك ده وجرب: http://localhost:${PORT}`);
})











// ====================== مسار التوصيات الذكية ======================
app.post("/api/recommend", async (req, res) => {
    try {
        const { 
            budget, 
            place_type, 
            food_categories,
            need_delivery = 0,
            need_outdoor = 0,
            need_family = 0,
            num_people = 1,
            top_n = 3 
        } = req.body;

        // هنا هتحتاج تستدعي الـ recommender function
        // لو عندك المودل في Python، ممكن تستخدم child_process أو تحول المنطق لـ JS
        // أو تشغل Flask معاه

        // حل مؤقت للاختبار:
        const results = [
            {
                name: "مطعم الشيف",
                area: "الإبراهيمية",
                avg_rating: 4.5,
                phone: "0123456789",
                type: "restaurant",
                min_price_after_tax: 80,
                max_price_after_tax: 180,
                opening_time: "11:00",
                closing_time: "23:00",
                tax_percentage: 14,
                has_delivery: true,
                has_outdoor: false,
                has_family_section: true,
                match_score: 0.92,
                best_items_in_budget: [
                    { item_name: "بيتزا مارجريتا", price_after_tax: 95 },
                    { item_name: "تشيكن فرايد", price_after_tax: 145 }
                ]
            }
        ];

        res.json({ results, count: results.length });

    } catch (error) {
        console.error("خطأ في التوصيات:", error);
        res.status(500).json({ error: "حصل خطأ في نظام التوصيات" });
    }
})